import React from 'react';
import {
  Moon,
  Type,
  Activity,
  Palette,
  Globe,
  Info,
  Shield,
  Sparkles,
} from 'lucide-react';

interface SettingsTabProps {
  fontSize: number;
  setFontSize: (size: number) => void;
  glowStrength: number;
  setGlowStrength: (strength: number) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  language: 'en' | 'hi';
  setLanguage: (lang: 'en' | 'hi') => void;
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  fontSize,
  setFontSize,
  glowStrength,
  setGlowStrength,
  darkMode,
  setDarkMode,
  language,
  setLanguage,
}) => {
  return (
    <div className="max-w-md mx-auto flex flex-col gap-6 pt-2 animate-in fade-in duration-200">
      {/* 1. Appearance Section */}
      <div className="flex flex-col gap-3">
        <label className="text-white/40 text-xs font-semibold uppercase tracking-wider">
          Appearance (दिखावट)
        </label>
        <div
          className="rounded-2xl p-4 flex flex-col gap-4"
          style={{
            background: '#141416',
            border: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          {/* Dark Mode */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400">
                <Moon size={18} />
              </div>
              <span className="text-white text-sm font-medium">Dark Mode</span>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`w-11 h-6 rounded-full transition-colors p-0.5 flex items-center ${
                darkMode ? 'bg-purple-600 justify-end' : 'bg-white/20 justify-start'
              }`}
            >
              <div className="w-5 h-5 rounded-full bg-white shadow-md" />
            </button>
          </div>

          {/* Font Size */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-blue-500/10 text-blue-400">
                  <Type size={18} />
                </div>
                <span className="text-white text-sm font-medium">Font Size</span>
              </div>
              <span className="text-white/60 text-xs font-mono">{fontSize}px</span>
            </div>
            <input
              type="range"
              min={16}
              max={48}
              value={fontSize}
              onChange={(e) => setFontSize(parseInt(e.target.value, 10))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          {/* Glow / Animation Intensity */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-pink-500/10 text-pink-400">
                  <Activity size={18} />
                </div>
                <span className="text-white text-sm font-medium">Glow Intensity</span>
              </div>
              <span className="text-white/60 text-xs font-mono">
                {Math.round(glowStrength * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={50}
              max={250}
              value={Math.round(glowStrength * 100)}
              onChange={(e) => setGlowStrength(parseInt(e.target.value, 10) / 100)}
              className="w-full accent-pink-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 2. Language & App Preferences */}
      <div className="flex flex-col gap-3">
        <label className="text-white/40 text-xs font-semibold uppercase tracking-wider">
          Preferences (प्राथमिकताएं)
        </label>
        <div
          className="rounded-2xl p-4 flex flex-col gap-4"
          style={{
            background: '#141416',
            border: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          {/* Language Toggle */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
                <Globe size={18} />
              </div>
              <span className="text-white text-sm font-medium">Language</span>
            </div>
            <div className="flex bg-black/40 p-1 rounded-xl border border-white/5 text-xs">
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 rounded-lg font-medium transition ${
                  language === 'en'
                    ? 'bg-purple-600 text-white'
                    : 'text-white/50 hover:text-white'
                }`}
              >
                English
              </button>
              <button
                onClick={() => setLanguage('hi')}
                className={`px-3 py-1 rounded-lg font-medium transition ${
                  language === 'hi'
                    ? 'bg-purple-600 text-white'
                    : 'text-white/50 hover:text-white'
                }`}
              >
                हिंदी
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 3. About & Info */}
      <div className="flex flex-col gap-3">
        <label className="text-white/40 text-xs font-semibold uppercase tracking-wider">
          About (ऐप के बारे में)
        </label>
        <div
          className="rounded-2xl p-4 flex flex-col gap-3"
          style={{
            background: '#141416',
            border: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          <div className="flex items-center justify-between py-1">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                <Sparkles size={18} />
              </div>
              <span className="text-white text-sm font-medium">NeonName Version</span>
            </div>
            <span className="text-white/40 text-xs font-mono">1.0.0</span>
          </div>

          <div className="flex items-center justify-between py-1">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                <Info size={18} />
              </div>
              <span className="text-white text-sm font-medium">Available Styles</span>
            </div>
            <span className="text-purple-400 text-xs font-bold font-mono">250+ Effects</span>
          </div>

          <div className="pt-2 border-t border-white/5 text-xs text-white/50 leading-relaxed">
            {language === 'hi'
              ? 'NeonName आपके नाम को शानदार नियॉन, 3D, ग्रेडिएंट, फायर, आइस और स्टाइलिश फॉन्ट्स में बदलता है। अपने दोस्तों के साथ शेयर करें या इंस्टाग्राम/व्हाट्सएप के लिए इमेज डाउनलोड करें।'
              : 'NeonName transforms your name into stunning neon, 3D, gradient, fire, ice, and stylized fonts. Share with friends or export high-res images for Instagram & WhatsApp.'}
          </div>
        </div>
      </div>
    </div>
  );
};
