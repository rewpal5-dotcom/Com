import React from 'react';
import {
  X,
  Home,
  Palette,
  Heart,
  Settings,
  BarChart3,
  History,
  Info,
  Sparkles,
} from 'lucide-react';
import { NavTab } from './BottomNav';

interface SidebarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavTab, extra?: { subTab?: 'favorites' | 'history' }) => void;
}

const MENU_ITEMS = [
  { label: 'Home', tab: 'home' as NavTab, icon: Home },
  { label: 'Styles', tab: 'styles' as NavTab, icon: Palette },
  { label: 'Favorites', tab: 'favorites' as NavTab, icon: Heart },
  { label: 'Settings', tab: 'settings' as NavTab, icon: Settings },
  { label: 'Analytics', tab: 'analytics' as NavTab, icon: BarChart3 },
  { label: 'History', tab: 'favorites' as NavTab, icon: History, subTab: 'history' as const },
  { label: 'About', tab: 'settings' as NavTab, icon: Info },
];

export const SidebarDrawer: React.FC<SidebarDrawerProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 z-50 animate-in fade-in-0 duration-200"
        onClick={onClose}
      />

      {/* Drawer */}
      <div
        className="fixed top-0 left-0 bottom-0 w-72 z-50 p-5 flex flex-col justify-between transition-transform animate-in slide-in-from-left duration-200"
        style={{
          background: '#141414',
          borderRight: '1px solid rgba(255,255,255,0.08)',
        }}
      >
        <div className="flex flex-col gap-1">
          {/* Header */}
          <div className="flex items-center justify-between mb-6 pb-2 border-b border-white/5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-400" />
              <span className="text-white font-bold text-lg">NeonName</span>
            </div>
            <button
              onClick={onClose}
              className="p-1 text-white/60 hover:text-white rounded-lg hover:bg-white/10 transition"
              title="Close Menu"
            >
              <X size={20} />
            </button>
          </div>

          {/* Links */}
          <div className="flex flex-col gap-1">
            {MENU_ITEMS.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={() => {
                    onClose();
                    onNavigate(item.tab, item.subTab ? { subTab: item.subTab } : undefined);
                  }}
                  className="flex items-center gap-3 text-left px-4 py-3 rounded-xl text-white/80 hover:text-white hover:bg-white/5 transition active:scale-[0.98]"
                >
                  <Icon size={18} className="text-purple-400/80" />
                  <span className="font-medium text-sm">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-white/5 rounded-xl border border-white/5 text-xs text-white/50">
          <p className="font-medium text-white/70">NeonName v1.0.0</p>
          <p className="text-[11px] mt-0.5">Stylish Neon & 3D Text Generator</p>
        </div>
      </div>
    </>
  );
};
