import React from 'react';
import { StyleDefinition, computeCharacterStyles, RenderStyleOptions } from '../data/neonStyles';

interface NameDisplayProps {
  name: string;
  style: StyleDefinition;
  size?: number;
  options?: RenderStyleOptions;
  className?: string;
}

export const NameDisplay: React.FC<NameDisplayProps> = ({
  name,
  style,
  size = 32,
  options = {},
  className = '',
}) => {
  if (!name) return null;

  const charStyles = computeCharacterStyles(name, style, options);

  return (
    <span
      className={`font-extrabold inline-flex flex-wrap justify-center items-center select-none ${className}`}
      style={{
        fontSize: `${size}px`,
        lineHeight: 1.2,
      }}
    >
      {charStyles.map(({ ch, style: s }, idx) => (
        <span key={idx} style={s}>
          {ch === ' ' ? '\u00A0' : ch}
        </span>
      ))}
    </span>
  );
};
