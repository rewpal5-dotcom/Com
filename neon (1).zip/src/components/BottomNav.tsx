import React from 'react';
import { Home, Palette, Heart, Settings } from 'lucide-react';

export type NavTab = 'home' | 'styles' | 'favorites' | 'settings' | 'analytics';

interface BottomNavProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  favoritesCount?: number;
}

const NAV_ITEMS: { id: NavTab; label: string; icon: React.FC<{ size?: number; className?: string; style?: React.CSSProperties }> }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'styles', label: 'Styles', icon: Palette },
  { id: 'favorites', label: 'Favorites', icon: Heart },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onTabChange,
  favoritesCount = 0,
}) => {
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around px-2 py-2"
      style={{
        background: '#121212',
        borderTop: '1px solid rgba(255,255,255,0.06)',
      }}
    >
      {NAV_ITEMS.map((item) => {
        const isActive = currentTab === item.id;
        const Icon = item.icon;

        return (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className="flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl transition relative"
            style={
              isActive
                ? {
                    background:
                      'linear-gradient(135deg, rgba(138,43,226,0.25), rgba(106,17,203,0.15))',
                    boxShadow: '0 0 12px rgba(138,43,226,0.4)',
                  }
                : {}
            }
          >
            <div className="relative">
              <Icon
                size={20}
                className={isActive ? 'text-purple-400' : 'text-white/60'}
                style={
                  isActive
                    ? { filter: 'drop-shadow(0 0 5px rgba(168,85,247,0.8))' }
                    : {}
                }
              />
              {item.id === 'favorites' && favoritesCount > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-pink-500 text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {favoritesCount}
                </span>
              )}
            </div>
            <span
              className={`text-[10px] font-medium ${
                isActive ? 'text-purple-400' : 'text-white/60'
              }`}
            >
              {item.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
