import React, { useState } from 'react';
import {
  CATEGORIES,
  Category,
  StyleDefinition,
  getStylesByCategory,
  PRESET_CUSTOM_COLORS,
  ALL_STYLES,
} from '../data/neonStyles';
import { NameDisplay } from './NameDisplay';
import { Check, Palette, Search, Sliders, Download, Copy } from 'lucide-react';
import { downloadNeonImage } from '../utils/imageExport';

interface StylesTabProps {
  currentStyle: StyleDefinition;
  onSelectStyle: (style: StyleDefinition) => void;
  previewName?: string;
  glowStrength?: number;
}

const TEXT_EFFECTS = ['None', 'Glow', 'Shadow', 'Sparkle', 'Neon'] as const;

export const StylesTab: React.FC<StylesTabProps> = ({
  currentStyle,
  onSelectStyle,
  previewName = 'Name',
  glowStrength = 1.2,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<Category>('All');
  const [selectedEffect, setSelectedEffect] = useState<string>('Glow');
  const [customColor, setCustomColor] = useState<string>('#8A2BE2');
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);

  // Filter styles by category and search
  const categoryStyles = getStylesByCategory(selectedCategory);
  const filteredStyles = categoryStyles.filter((st) =>
    st.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleApplyCustomColor = (hex: string) => {
    setCustomColor(hex);
    // Create custom dynamic variant
    const customStyle: StyleDefinition = {
      id: `custom_${Date.now()}`,
      name: `Custom (${hex.toUpperCase()})`,
      colors: [hex, '#FFFFFF', hex, '#FFD700'],
      effect: currentStyle.effect,
    };
    onSelectStyle(customStyle);
  };

  const handleDownloadPreview = () => {
    downloadNeonImage(previewName || 'NeonName', currentStyle, { glowStrength });
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(previewName);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {}
  };

  return (
    <div className="max-w-md mx-auto flex flex-col gap-6 pt-2 animate-in fade-in duration-200">
      {/* Category Filter Horizontal Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className="px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition active:scale-95"
              style={
                isActive
                  ? {
                      background: 'linear-gradient(135deg, #8A2BE2, #6A11CB)',
                      color: '#fff',
                      boxShadow: '0 0 10px rgba(138,43,226,0.4)',
                    }
                  : {
                      background: '#171717',
                      color: 'rgba(255,255,255,0.6)',
                    }
              }
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Search Filter */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={`Search ${filteredStyles.length} styles...`}
          className="w-full bg-[#141416] border border-white/10 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder-white/30 outline-none focus:border-purple-500"
        />
      </div>

      {/* Active Style Preview Strip */}
      <div
        className="rounded-2xl p-4 flex items-center justify-between gap-3 border border-purple-500/30"
        style={{
          background: 'linear-gradient(135deg, #181424, #12101b)',
        }}
      >
        <div className="flex flex-col gap-1 min-w-0">
          <span className="text-[11px] text-purple-300 font-semibold uppercase tracking-wider">
            Active: {currentStyle.name} ({currentStyle.effect})
          </span>
          <NameDisplay
            name={previewName || 'NeonName'}
            style={currentStyle}
            size={22}
            options={{ glowStrength }}
          />
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <button
            onClick={handleCopy}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition active:scale-95"
            title="Copy Text"
          >
            {copied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
          </button>
          <button
            onClick={handleDownloadPreview}
            className="p-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition active:scale-95"
            title="Download PNG"
          >
            <Download size={16} />
          </button>
        </div>
      </div>

      {/* Choose Color Style (Grid 2-cols) */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <label className="text-white/90 text-sm font-medium">Choose Color Style</label>
          <span className="text-white/40 text-xs font-mono">{filteredStyles.length} styles</span>
        </div>

        <div className="grid grid-cols-2 gap-3 max-h-[460px] overflow-y-auto pr-1">
          {filteredStyles.map((st) => {
            const isSelected = currentStyle.id === st.id;
            return (
              <button
                key={st.id}
                onClick={() => onSelectStyle(st)}
                className="relative rounded-2xl p-4 flex flex-col items-center gap-2 transition active:scale-95 select-none"
                style={
                  isSelected
                    ? {
                        background: '#171717',
                        border: '2px solid #8A2BE2',
                        boxShadow: '0 0 14px rgba(138,43,226,0.35)',
                      }
                    : {
                        background: '#171717',
                        border: '1px solid rgba(255,255,255,0.05)',
                      }
                }
              >
                {isSelected && (
                  <span
                    className="absolute top-2 right-2 w-5 h-5 rounded-full flex items-center justify-center"
                    style={{ background: '#8A2BE2' }}
                  >
                    <Check size={12} className="text-white" />
                  </span>
                )}
                <NameDisplay name={previewName || 'Name'} style={st} size={20} />
                <span className="text-white/60 text-xs font-medium truncate w-full text-center">
                  {st.name}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Customize Colors Palette */}
      <div className="flex flex-col gap-3">
        <label className="text-white/90 text-sm font-medium">Customize Colors</label>
        <div className="flex items-center gap-3 overflow-x-auto pb-1 no-scrollbar">
          {PRESET_CUSTOM_COLORS.map((hex) => (
            <button
              key={hex}
              onClick={() => handleApplyCustomColor(hex)}
              className="w-9 h-9 rounded-full flex-shrink-0 transition active:scale-90"
              style={{
                background: hex,
                border:
                  customColor === hex
                    ? '2px solid #fff'
                    : '1px solid rgba(255,255,255,0.15)',
                boxShadow: `0 0 8px ${hex}66`,
              }}
              title={hex}
            />
          ))}

          {/* Color input picker */}
          <label
            className="w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center cursor-pointer transition active:scale-90"
            style={{
              border: '1px solid rgba(255,255,255,0.2)',
              background: '#171717',
            }}
            title="Custom Hex Color"
          >
            <Palette size={16} className="text-white/60" />
            <input
              type="color"
              value={customColor}
              onChange={(e) => handleApplyCustomColor(e.target.value)}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Text Effects Filter */}
      <div className="flex flex-col gap-3 pb-6">
        <label className="text-white/90 text-sm font-medium">Text Effects</label>
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {TEXT_EFFECTS.map((eff) => {
            const isActive = selectedEffect === eff;
            return (
              <button
                key={eff}
                onClick={() => {
                  setSelectedEffect(eff);
                  // Apply corresponding effect
                  if (eff === 'Neon') setSelectedCategory('Neon');
                  else if (eff === 'Glow') setSelectedCategory('Glow');
                  else if (eff === 'Shadow') setSelectedCategory('Shadow');
                }}
                className="px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition active:scale-95"
                style={
                  isActive
                    ? {
                        background: 'linear-gradient(135deg, #8A2BE2, #6A11CB)',
                        color: '#fff',
                        boxShadow: '0 0 10px rgba(138,43,226,0.4)',
                      }
                    : {
                        background: '#171717',
                        color: 'rgba(255,255,255,0.6)',
                      }
                }
              >
                {eff}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
