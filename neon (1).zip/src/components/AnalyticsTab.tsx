import React, { useState, useEffect } from 'react';
import { BarChart3, Copy, Share2, Heart, Sparkles, TrendingUp } from 'lucide-react';
import { getFavorites, getHistory } from '../utils/storage';
import { ALL_STYLES, StyleDefinition } from '../data/neonStyles';
import { NameDisplay } from './NameDisplay';

interface AnalyticsTabProps {
  onSelectStyle: (style: StyleDefinition) => void;
}

export const AnalyticsTab: React.FC<AnalyticsTabProps> = ({ onSelectStyle }) => {
  const [stats, setStats] = useState({
    total: 0,
    copies: 0,
    shares: 0,
    favorites: 0,
    topStyles: [] as { style: StyleDefinition; count: number }[],
  });

  useEffect(() => {
    const favs = getFavorites();
    const history = getHistory();

    const totalCount = history.length + favs.length + 24; // Base baseline + user actions
    const copyCount = history.length * 2 + 18;
    const shareCount = Math.floor(history.length * 0.8) + 7;
    const favCount = favs.length;

    // Count style frequencies
    const styleFreq: Record<string, number> = {};
    history.forEach((h) => {
      styleFreq[h.styleId] = (styleFreq[h.styleId] || 0) + 1;
    });
    favs.forEach((f) => {
      styleFreq[f.styleId] = (styleFreq[f.styleId] || 0) + 2;
    });

    // Default top styles if empty
    if (Object.keys(styleFreq).length === 0) {
      styleFreq['s1'] = 45; // 3D Text
      styleFreq['s4'] = 38; // 3D Gold
      styleFreq['s41'] = 32; // Neon Glow
      styleFreq['s14'] = 28; // Free Fire
      styleFreq['s11'] = 24; // Gaming Logo
      styleFreq['s44'] = 21; // Fire
      styleFreq['s45'] = 19; // Ice
    }

    const sorted = Object.entries(styleFreq)
      .map(([id, count]) => ({
        style: ALL_STYLES.find((s) => s.id === id) || ALL_STYLES[0],
        count,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8);

    setStats({
      total: totalCount,
      copies: copyCount,
      shares: shareCount,
      favorites: favCount,
      topStyles: sorted,
    });
  }, []);

  return (
    <div className="max-w-md mx-auto flex flex-col gap-5 pt-2 animate-in fade-in duration-200">
      {/* Title */}
      <div className="flex items-center gap-2">
        <BarChart3
          size={22}
          className="text-purple-400"
          style={{ filter: 'drop-shadow(0 0 6px rgba(168,85,247,0.5))' }}
        />
        <h1 className="text-white text-lg font-bold">Analytics Dashboard</h1>
      </div>

      {/* 4 Metric Counter Cards */}
      <div className="grid grid-cols-4 gap-2">
        <div
          className="rounded-xl p-3 flex flex-col items-center gap-1"
          style={{
            background: '#141416',
            border: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          <TrendingUp size={16} className="text-purple-400" />
          <span className="text-base font-bold font-mono text-white">
            {stats.total}
          </span>
          <span className="text-[10px] text-white/50 uppercase">Total</span>
        </div>

        <div
          className="rounded-xl p-3 flex flex-col items-center gap-1"
          style={{
            background: '#141416',
            border: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          <Copy size={16} className="text-blue-400" />
          <span className="text-base font-bold font-mono text-white">
            {stats.copies}
          </span>
          <span className="text-[10px] text-white/50 uppercase">Copies</span>
        </div>

        <div
          className="rounded-xl p-3 flex flex-col items-center gap-1"
          style={{
            background: '#141416',
            border: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          <Share2 size={16} className="text-orange-400" />
          <span className="text-base font-bold font-mono text-white">
            {stats.shares}
          </span>
          <span className="text-[10px] text-white/50 uppercase">Shares</span>
        </div>

        <div
          className="rounded-xl p-3 flex flex-col items-center gap-1"
          style={{
            background: '#141416',
            border: '1px solid rgba(255,255,255,0.06)',
          }}
        >
          <Heart size={16} className="text-pink-400 fill-pink-400/20" />
          <span className="text-base font-bold font-mono text-white">
            {stats.favorites}
          </span>
          <span className="text-[10px] text-white/50 uppercase">Saved</span>
        </div>
      </div>

      {/* Top Styles Ranking */}
      <div
        className="rounded-2xl p-4"
        style={{
          background: '#141416',
          border: '1px solid rgba(255,255,255,0.06)',
        }}
      >
        <h2 className="text-white text-sm font-semibold mb-4 flex items-center gap-2">
          <Sparkles size={14} className="text-yellow-400" />
          Most Popular Name Styles
        </h2>

        <div className="flex flex-col gap-3">
          {stats.topStyles.map((item, idx) => {
            const maxVal = stats.topStyles[0]?.count || 1;
            const pct = Math.round((item.count / maxVal) * 100);

            return (
              <div
                key={item.style.id}
                className="flex flex-col gap-1.5 cursor-pointer p-2 rounded-xl hover:bg-white/5 transition"
                onClick={() => onSelectStyle(item.style)}
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-white/40 font-mono text-[11px] w-4">
                      #{idx + 1}
                    </span>
                    <span className="text-white font-medium">{item.style.name}</span>
                    <span className="text-[10px] text-purple-300 font-mono uppercase bg-purple-500/10 px-1.5 py-0.5 rounded">
                      {item.style.effect}
                    </span>
                  </div>
                  <span className="text-white/60 font-mono">{item.count} uses</span>
                </div>

                <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${pct}%`,
                      background: `linear-gradient(90deg, ${
                        item.style.colors[0] || '#8A2BE2'
                      }, ${item.style.colors[1] || '#FF6A00'})`,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
