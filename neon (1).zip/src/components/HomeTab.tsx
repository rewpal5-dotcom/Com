import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  X,
  Copy,
  Check,
  Share2,
  Heart,
  Palette,
  Sliders,
  Download,
  Flame,
  CheckCircle,
  ExternalLink,
  Crown,
} from 'lucide-react';
import { StyleDefinition, ALL_STYLES, SPECIAL_GOLU_STYLE } from '../data/neonStyles';
import { NameDisplay } from './NameDisplay';
import { generateAllUnicodeStyles } from '../utils/unicodeFonts';
import { downloadNeonImage } from '../utils/imageExport';
import { SavedNameItem, saveFavorites, getFavorites, saveHistory, getHistory } from '../utils/storage';
import { NavTab } from './BottomNav';

interface HomeTabProps {
  onNavigate: (tab: NavTab) => void;
  selectedStyle: StyleDefinition;
  onSelectStyle: (style: StyleDefinition) => void;
  fontSize?: number;
  glowStrength?: number;
}

export const HomeTab: React.FC<HomeTabProps> = ({
  onNavigate,
  selectedStyle,
  onSelectStyle,
  fontSize = 34,
  glowStrength = 1.2,
}) => {
  const [name, setName] = useState('Sourabh');
  const [generatedName, setGeneratedName] = useState('Sourabh');
  const [copiedMain, setCopiedMain] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [isSaved, setIsSaved] = useState(false);
  const [selectedUnicodeText, setSelectedUnicodeText] = useState<string>('');
  const [isSpecialUnlocked, setIsSpecialUnlocked] = useState(false);

  // Compute unicode variations
  const unicodeList = generateAllUnicodeStyles(generatedName || name);

  // Check if currently saved in favorites
  useEffect(() => {
    if (!generatedName) {
      setIsSaved(false);
      return;
    }
    const favs = getFavorites();
    const exists = favs.some(
      (f) => f.name === generatedName && f.styleId === selectedStyle.id
    );
    setIsSaved(exists);
  }, [generatedName, selectedStyle]);

  const handleGenerate = () => {
    if (!name.trim()) return;
    const trimmed = name.trim();
    setGeneratedName(trimmed);

    // Save to history
    const history = getHistory();
    const newItem: SavedNameItem = {
      id: crypto.randomUUID(),
      name: trimmed,
      styleId: selectedStyle.id,
      unicodeText: selectedUnicodeText || undefined,
      ts: Date.now(),
    };
    saveHistory([newItem, ...history.filter((h) => h.name !== trimmed).slice(0, 49)]);
  };

  const handleCopyMain = async () => {
    const textToCopy = selectedUnicodeText || generatedName;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopiedMain(true);
      setTimeout(() => setCopiedMain(false), 2000);
    } catch {
      // fallback
    }
  };

  const handleCopyUnicode = async (text: string, index: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setSelectedUnicodeText(text);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 1500);
    } catch {
      // fallback
    }
  };

  const handleToggleFavorite = () => {
    if (!generatedName) return;
    const favs = getFavorites();
    if (isSaved) {
      const filtered = favs.filter(
        (f) => !(f.name === generatedName && f.styleId === selectedStyle.id)
      );
      saveFavorites(filtered);
      setIsSaved(false);
    } else {
      const newItem: SavedNameItem = {
        id: crypto.randomUUID(),
        name: generatedName,
        styleId: selectedStyle.id,
        unicodeText: selectedUnicodeText || undefined,
        ts: Date.now(),
      };
      saveFavorites([newItem, ...favs]);
      setIsSaved(true);
    }
  };

  const handleShare = async () => {
    const textToShare = selectedUnicodeText || generatedName;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'NeonName - My Stylish Name',
          text: `Check out my neon styled name: ${textToShare}`,
          url: window.location.href,
        });
      } catch {
        handleCopyMain();
      }
    } else {
      handleCopyMain();
    }
  };

  const handleDownloadPng = () => {
    if (!generatedName) return;
    downloadNeonImage(generatedName, selectedStyle, {
      glowStrength,
      fontSize,
    });
  };

  const handleUnlockSpecial = () => {
    setIsSpecialUnlocked(true);
    onSelectStyle(SPECIAL_GOLU_STYLE);
  };

  return (
    <div className="max-w-md mx-auto flex flex-col gap-5 pt-2 animate-in fade-in duration-200">
      {/* 1. Enter Your Name Card */}
      <div className="flex flex-col gap-2">
        <label className="text-white/90 text-sm font-medium">Enter Your Name</label>
        <div className="relative">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
            placeholder="Enter your name"
            autoFocus
            maxLength={30}
            className="w-full bg-transparent text-white px-4 py-3.5 pr-11 rounded-2xl outline-none placeholder:text-white/30 text-base"
            style={{ border: '1px solid #2B2B3A', background: '#141416' }}
          />
          {name && (
            <button
              onClick={() => setName('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white p-1"
              title="Clear text"
            >
              <X size={18} />
            </button>
          )}
        </div>

        <div className="flex justify-between items-center px-1">
          <span className="text-white/30 text-xs">{name.length}/30</span>
          <span className="text-purple-400 text-xs font-medium cursor-pointer hover:underline" onClick={() => setName('RoyalKing')}>
            Try: RoyalKing
          </span>
        </div>

        <button
          onClick={handleGenerate}
          className="flex items-center justify-center gap-2 py-3.5 rounded-2xl font-semibold text-white transition active:scale-[0.98] shadow-lg"
          style={{
            background: 'linear-gradient(135deg, #6A11CB, #FF6A00)',
            boxShadow: '0 4px 20px rgba(106,17,203,0.4)',
          }}
        >
          <Sparkles size={18} />
          <span>Generate Name</span>
        </button>
      </div>

      {/* 2. Generated Name Showcase */}
      {generatedName && (
        <div className="flex flex-col gap-2.5 animate-in fade-in duration-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <label className="text-white/90 text-sm font-medium">Generated Name</label>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-mono">
                {selectedStyle.name}
              </span>
            </div>
            <button
              onClick={() => setGeneratedName('')}
              className="text-white/40 hover:text-white p-0.5"
              title="Hide preview"
            >
              <X size={16} />
            </button>
          </div>

          <div
            className="relative rounded-2xl p-6 flex flex-col items-center justify-center min-h-[140px] overflow-hidden select-none"
            style={{
              background: 'linear-gradient(135deg, #161618, #1A1A1E)',
              border: '1px solid rgba(255,255,255,0.06)',
            }}
          >
            <Heart
              size={18}
              className={`absolute top-3 right-3 cursor-pointer transition ${
                isSaved
                  ? 'text-pink-500 fill-pink-500'
                  : 'text-white/20 hover:text-pink-400'
              }`}
              onClick={handleToggleFavorite}
              style={{ filter: isSaved ? 'drop-shadow(0 0 6px rgba(236,72,153,0.7))' : undefined }}
            />

            <NameDisplay
              name={generatedName}
              style={selectedStyle}
              size={fontSize}
              options={{ glowStrength }}
            />

            {selectedUnicodeText && (
              <span className="mt-3 text-xs text-white/50 font-mono tracking-wide">
                {selectedUnicodeText}
              </span>
            )}
          </div>

          {/* Action buttons (Copy, Share, Save, Download Image) */}
          <div className="grid grid-cols-4 gap-2 mt-0.5">
            <button
              onClick={handleCopyMain}
              className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-medium text-white transition active:scale-[0.98]"
              style={{ background: 'linear-gradient(135deg, #1e3a8a, #1e40af)' }}
            >
              {copiedMain ? <Check size={14} className="text-green-300" /> : <Copy size={14} />}
              <span>{copiedMain ? 'Copied' : 'Copy'}</span>
            </button>

            <button
              onClick={handleShare}
              className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-medium text-white transition active:scale-[0.98]"
              style={{ background: 'linear-gradient(135deg, #1e3a8a, #1e40af)' }}
            >
              <Share2 size={14} />
              <span>Share</span>
            </button>

            <button
              onClick={handleToggleFavorite}
              className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-medium text-white transition active:scale-[0.98]"
              style={
                isSaved
                  ? { background: 'linear-gradient(135deg, #8A2BE2, #6A11CB)' }
                  : { background: 'linear-gradient(135deg, #1e3a8a, #1e40af)' }
              }
            >
              <Heart size={14} className={isSaved ? 'fill-white' : ''} />
              <span>{isSaved ? 'Saved' : 'Save'}</span>
            </button>

            <button
              onClick={handleDownloadPng}
              className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-medium text-white transition active:scale-[0.98] bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500"
              title="Download High-Res PNG Image"
            >
              <Download size={14} />
              <span>Image</span>
            </button>
          </div>
        </div>
      )}

      {/* 3. Special Style Unlock Card */}
      <div className="flex flex-col gap-3">
        <button
          onClick={handleUnlockSpecial}
          className="flex items-center gap-3 rounded-2xl p-3 transition active:scale-[0.98]"
          style={{
            background: 'linear-gradient(135deg, #1A1A1A, #141416)',
            border: '1px solid rgba(255,255,255,0.08)',
          }}
        >
          <div className="relative flex-shrink-0">
            <div
              className="w-12 h-12 rounded-full p-[2px] flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #77d3f5, #ffffff, #77d3f5)',
                boxShadow: '0 0 12px rgba(119,211,245,0.6)',
              }}
            >
              <Crown className="w-6 h-6 text-yellow-400" />
            </div>
            {isSpecialUnlocked && (
              <span className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full flex items-center justify-center bg-green-500 border-2 border-[#141416]">
                <Check size={10} className="text-white" />
              </span>
            )}
          </div>

          <div className="flex-1 text-left">
            <div className="flex items-center gap-1.5">
              <Sparkles size={14} className="text-cyan-400" />
              <span className="text-white text-sm font-semibold">
                {isSpecialUnlocked ? 'Golu Special Unlocked!' : 'Unlock Special Style'}
              </span>
            </div>
            <span className="text-white/40 text-xs">
              {isSpecialUnlocked ? 'Gold & Hot Pink neon style active' : 'Click to unlock VIP Golu special style'}
            </span>
          </div>

          <div className="flex-shrink-0">
            {isSpecialUnlocked ? (
              <CheckCircle size={18} className="text-green-400" />
            ) : (
              <ExternalLink size={18} className="text-white/40" />
            )}
          </div>
        </button>

        {isSpecialUnlocked && (
          <div
            className="rounded-2xl p-4 flex items-center justify-between gap-3 animate-in fade-in"
            style={{
              background:
                'linear-gradient(135deg, rgba(255,215,0,0.08), rgba(255,20,147,0.08))',
              border: '1px solid rgba(255,215,0,0.25)',
            }}
          >
            <div className="flex flex-col gap-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <Sparkles size={13} className="text-yellow-400" />
                <span className="text-white/80 text-xs font-medium">Special Style Unlocked</span>
              </div>
              <NameDisplay name={generatedName || 'Golu'} style={SPECIAL_GOLU_STYLE} size={20} />
            </div>
            <button
              onClick={() => onSelectStyle(SPECIAL_GOLU_STYLE)}
              className="flex-shrink-0 px-4 py-2 rounded-xl text-xs font-semibold text-white shadow"
              style={{ background: 'linear-gradient(135deg, #FFD700, #FF1493)' }}
            >
              Apply
            </button>
          </div>
        )}
      </div>

      {/* 4. Copy Style (Unicode) List */}
      {unicodeList.length > 0 && (
        <div className="flex flex-col gap-2">
          <label className="text-white/90 text-sm font-medium">Copy Style (Unicode)</label>
          <p className="text-white/40 text-xs -mt-1">
            Tap any style to copy the fancy Unicode text
          </p>
          <div className="flex flex-col gap-2 max-h-72 overflow-y-auto pr-1">
            {unicodeList.map((item, idx) => {
              const isSelected = selectedUnicodeText === item.text;
              return (
                <button
                  key={idx}
                  onClick={() => handleCopyUnicode(item.text, idx)}
                  className="flex items-center justify-between rounded-xl px-3.5 py-3 transition active:scale-[0.98]"
                  style={
                    isSelected
                      ? { background: '#1E1A2E', border: '1px solid #8A2BE2' }
                      : { background: '#1A1A1A', border: '1px solid rgba(255,255,255,0.05)' }
                  }
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {isSelected && (
                      <Sparkles size={12} className="text-purple-400 fill-purple-400 flex-shrink-0" />
                    )}
                    <span
                      className="text-base font-medium truncate"
                      style={
                        item.label === 'Flag Letters'
                          ? {
                              fontFamily: 'system-ui',
                              background:
                                'linear-gradient(90deg, #FF0000, #FF7F00, #FFFF00, #00FF00, #0000FF, #4B0082, #9400D3)',
                              WebkitBackgroundClip: 'text',
                              WebkitTextFillColor: 'transparent',
                            }
                          : { fontFamily: 'system-ui', color: '#fff' }
                      }
                    >
                      {item.text}
                    </span>
                  </div>

                  <span className="flex items-center gap-1 text-white/40 text-xs flex-shrink-0 ml-2">
                    {copiedIndex === idx ? (
                      <>
                        <Check size={13} className="text-green-400" /> Copied
                      </>
                    ) : (
                      <>
                        <Copy size={13} /> Copy
                      </>
                    )}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. More Options Navigation Cards */}
      <div className="flex flex-col gap-2">
        <label className="text-white/90 text-sm font-medium">More Options</label>
        <div className="grid grid-cols-3 gap-3">
          <button
            onClick={() => onNavigate('styles')}
            className="flex flex-col items-center gap-2 py-4 rounded-2xl transition hover:bg-white/5 active:scale-95"
            style={{
              background: '#1A1A1A',
              border: '1px solid rgba(255,255,255,0.05)',
            }}
          >
            <Palette
              size={26}
              className="text-purple-400"
              style={{ filter: 'drop-shadow(0 0 6px rgba(168,85,247,0.5))' }}
            />
            <span className="text-white text-xs font-medium">Styles (250+)</span>
          </button>

          <button
            onClick={() => onNavigate('favorites')}
            className="flex flex-col items-center gap-2 py-4 rounded-2xl transition hover:bg-white/5 active:scale-95"
            style={{
              background: '#1A1A1A',
              border: '1px solid rgba(255,255,255,0.05)',
            }}
          >
            <Heart
              size={26}
              className="text-pink-400"
              style={{ filter: 'drop-shadow(0 0 6px rgba(236,72,153,0.5))' }}
            />
            <span className="text-white text-xs font-medium">Favorites</span>
          </button>

          <button
            onClick={() => onNavigate('settings')}
            className="flex flex-col items-center gap-2 py-4 rounded-2xl transition hover:bg-white/5 active:scale-95"
            style={{
              background: '#1A1A1A',
              border: '1px solid rgba(255,255,255,0.05)',
            }}
          >
            <Sliders
              size={26}
              className="text-cyan-400"
              style={{ filter: 'drop-shadow(0 0 6px rgba(6,182,212,0.5))' }}
            />
            <span className="text-white text-xs font-medium">Settings</span>
          </button>
        </div>
      </div>

      {/* 6. Quick Style Horizontal Selector */}
      <div className="flex flex-col gap-2">
        <label className="text-white/90 text-sm font-medium">Quick Style</label>
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {ALL_STYLES.slice(0, 35).map((st) => {
            const isSelected = selectedStyle.id === st.id;
            return (
              <button
                key={st.id}
                onClick={() => onSelectStyle(st)}
                className="px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition active:scale-95"
                style={
                  isSelected
                    ? {
                        background:
                          'linear-gradient(135deg, rgba(138,43,226,0.3), rgba(106,17,203,0.2))',
                        border: '1px solid #8A2BE2',
                        color: '#fff',
                        boxShadow: '0 0 8px rgba(138,43,226,0.4)',
                      }
                    : {
                        background: '#1A1A1A',
                        border: '1px solid rgba(255,255,255,0.05)',
                        color: 'rgba(255,255,255,0.6)',
                      }
                }
              >
                {st.name}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
