import React, { useState, useEffect } from 'react';
import {
  Heart,
  History,
  Copy,
  Check,
  Trash2,
  Download,
  AlertCircle,
} from 'lucide-react';
import {
  SavedNameItem,
  getFavorites,
  saveFavorites,
  getHistory,
  saveHistory,
  formatTimestamp,
} from '../utils/storage';
import { ALL_STYLES, StyleDefinition } from '../data/neonStyles';
import { NameDisplay } from './NameDisplay';
import { downloadNeonImage } from '../utils/imageExport';

interface FavoritesTabProps {
  initialSubTab?: 'favorites' | 'history';
  onSelectStyle?: (style: StyleDefinition) => void;
}

export const FavoritesTab: React.FC<FavoritesTabProps> = ({
  initialSubTab = 'favorites',
  onSelectStyle,
}) => {
  const [subTab, setSubTab] = useState<'favorites' | 'history'>(initialSubTab);
  const [favorites, setFavorites] = useState<SavedNameItem[]>([]);
  const [history, setHistory] = useState<SavedNameItem[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    setFavorites(getFavorites());
    setHistory(getHistory());
  }, []);

  const currentList = subTab === 'favorites' ? favorites : history;
  const setCurrentList = (items: SavedNameItem[]) => {
    if (subTab === 'favorites') {
      setFavorites(items);
      saveFavorites(items);
    } else {
      setHistory(items);
      saveHistory(items);
    }
  };

  const getStyleById = (id: string): StyleDefinition => {
    return ALL_STYLES.find((s) => s.id === id) || ALL_STYLES[0];
  };

  const handleCopy = async (item: SavedNameItem) => {
    const textToCopy = item.unicodeText || item.name;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopiedId(item.id);
      setTimeout(() => setCopiedId(null), 1500);
    } catch {}
  };

  const handleDelete = (id: string) => {
    const filtered = currentList.filter((item) => item.id !== id);
    setCurrentList(filtered);
  };

  const handleClearAll = () => {
    if (window.confirm(`Are you sure you want to clear all ${subTab}?`)) {
      setCurrentList([]);
    }
  };

  const handleDownload = (item: SavedNameItem) => {
    const st = getStyleById(item.styleId);
    downloadNeonImage(item.name, st);
  };

  return (
    <div className="max-w-md mx-auto flex flex-col gap-4 pt-2 animate-in fade-in duration-200">
      {/* Subtab Segmented Switcher */}
      <div className="flex p-1 rounded-xl bg-[#171717] border border-white/5">
        {(['favorites', 'history'] as const).map((tab) => {
          const isActive = subTab === tab;
          return (
            <button
              key={tab}
              onClick={() => setSubTab(tab)}
              className="flex-1 py-2 rounded-lg text-sm font-medium capitalize transition active:scale-95 flex items-center justify-center gap-2"
              style={
                isActive
                  ? {
                      background: 'linear-gradient(135deg, #8A2BE2, #6A11CB)',
                      color: '#fff',
                      boxShadow: '0 0 10px rgba(138,43,226,0.3)',
                    }
                  : { color: 'rgba(255,255,255,0.5)' }
              }
            >
              {tab === 'favorites' ? <Heart size={14} className={isActive ? 'fill-white' : ''} /> : <History size={14} />}
              <span>{tab} ({tab === 'favorites' ? favorites.length : history.length})</span>
            </button>
          );
        })}
      </div>

      {/* List items */}
      {currentList.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-white/40 bg-white/5 rounded-2xl border border-white/5 p-8 text-center">
          {subTab === 'favorites' ? (
            <Heart size={44} className="mb-3 text-pink-500/40" />
          ) : (
            <History size={44} className="mb-3 text-purple-500/40" />
          )}
          <h3 className="text-base font-bold text-white mb-1">
            No {subTab} yet
          </h3>
          <p className="text-xs text-white/50 max-w-xs">
            {subTab === 'favorites'
              ? 'Click the heart icon on any generated name to save your favorite stylish names.'
              : 'Names you generate will automatically be recorded here in history.'}
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-2.5">
          {currentList.map((item) => {
            const style = getStyleById(item.styleId);
            return (
              <div
                key={item.id}
                className="flex items-center justify-between rounded-2xl p-3.5 transition hover:border-purple-500/30"
                style={{
                  background: '#1A1A1A',
                  border: '1px solid rgba(255,255,255,0.05)',
                }}
              >
                <div
                  className="flex flex-col gap-1 min-w-0 flex-1 cursor-pointer"
                  onClick={() => onSelectStyle && onSelectStyle(style)}
                >
                  <div className="flex items-center gap-2">
                    <NameDisplay name={item.name} style={style} size={19} />
                    <span className="text-[10px] text-white/40 font-mono">
                      {style.name}
                    </span>
                  </div>

                  {item.unicodeText && (
                    <span
                      className="text-white/60 text-xs font-medium truncate"
                      style={{ fontFamily: 'system-ui' }}
                    >
                      {item.unicodeText}
                    </span>
                  )}

                  <span className="text-white/30 text-[11px]">
                    {formatTimestamp(item.ts)}
                  </span>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                  <button
                    onClick={() => handleCopy(item)}
                    className="w-8 h-8 rounded-full flex items-center justify-center transition active:scale-90"
                    style={{ background: '#222' }}
                    title="Copy Text"
                  >
                    {copiedId === item.id ? (
                      <Check size={14} className="text-green-400" />
                    ) : (
                      <Copy size={14} className="text-white/70" />
                    )}
                  </button>

                  <button
                    onClick={() => handleDownload(item)}
                    className="w-8 h-8 rounded-full flex items-center justify-center transition active:scale-90"
                    style={{ background: '#222' }}
                    title="Download PNG"
                  >
                    <Download size={14} className="text-purple-400" />
                  </button>

                  <button
                    onClick={() => handleDelete(item.id)}
                    className="w-8 h-8 rounded-full flex items-center justify-center transition active:scale-90"
                    style={{ background: '#222' }}
                    title="Delete"
                  >
                    <Trash2 size={14} className="text-red-400" />
                  </button>
                </div>
              </div>
            );
          })}

          <button
            onClick={handleClearAll}
            className="w-full py-3.5 rounded-2xl font-semibold text-white mt-2 transition active:scale-[0.98] border border-red-500/20"
            style={{ background: 'linear-gradient(135deg, #7F1D1D, #0D0D0D)' }}
          >
            Clear All {subTab === 'favorites' ? 'Favorites' : 'History'}
          </button>
        </div>
      )}
    </div>
  );
};
