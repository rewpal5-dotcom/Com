import React from 'react';
import { Menu, Sparkles, Crown } from 'lucide-react';
import { RAINBOW_COLORS } from '../data/neonStyles';

interface HeaderProps {
  onMenu: () => void;
  onRandomName?: () => void;
}

const TITLE = 'Name Color Generator';

export const Header: React.FC<HeaderProps> = ({ onMenu, onRandomName }) => {
  return (
    <div className="flex items-center justify-between px-4 pt-4 pb-3 border-b border-white/5 bg-[#121212]/80 backdrop-blur-md sticky top-0 z-30">
      {/* Left: Hamburger menu */}
      <button
        onClick={onMenu}
        className="text-white/90 hover:text-white p-1 rounded-lg hover:bg-white/5 transition"
        title="Open Menu"
      >
        <Menu size={24} />
      </button>

      {/* Center: Glowing rainbow title */}
      <div className="flex items-center gap-1.5 select-none">
        <Sparkles
          size={14}
          className="text-yellow-300 fill-yellow-300"
          style={{ filter: 'drop-shadow(0 0 5px rgba(255,215,0,0.7))' }}
        />
        <h1 className="text-base sm:text-lg font-extrabold tracking-tight flex">
          {TITLE.split('').map((char, idx) => {
            const color = RAINBOW_COLORS[idx % RAINBOW_COLORS.length];
            return (
              <span
                key={idx}
                style={{
                  color,
                  textShadow: `0 0 8px ${color}, 0 0 16px ${color}`,
                }}
              >
                {char === ' ' ? '\u00A0' : char}
              </span>
            );
          })}
        </h1>
        <Sparkles
          size={14}
          className="text-yellow-300 fill-yellow-300"
          style={{ filter: 'drop-shadow(0 0 5px rgba(255,215,0,0.7))' }}
        />
      </div>

      {/* Right: Random Name generator / VIP Crown */}
      <button
        onClick={onRandomName}
        className="text-yellow-400 hover:text-yellow-300 p-1 rounded-lg hover:bg-yellow-400/10 transition"
        style={{ filter: 'drop-shadow(0 0 6px rgba(255,215,0,0.5))' }}
        title="Random Popular Name"
      >
        <Crown size={22} />
      </button>
    </div>
  );
};
