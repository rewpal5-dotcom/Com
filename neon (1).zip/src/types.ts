export type VideoType = 'realistic' | 'avatar' | 'story' | 'cinematic' | 'anime' | '3d-render';
export type SoraModel = 'sora-2' | 'sora-2-pro';
export type VideoResolution = '1280x720' | '720x1280' | '1080x1080' | '1920x1080';
export type CameraMotion = 'dynamic' | 'drone' | 'tracking' | 'low-angle' | 'orbit' | 'static';

export interface VideoItem {
  id: string;
  prompt: string;
  enhancedPrompt?: string;
  video_type: VideoType;
  model: SoraModel;
  size: VideoResolution;
  duration: number; // in seconds
  status: 'ready' | 'generating' | 'failed';
  progress?: number;
  cameraMovement?: CameraMotion;
  createdAt: string;
  fps?: number;
}
