export type StyleEffect =
  | "neon"
  | "glow"
  | "3d"
  | "metallic"
  | "gradient"
  | "shadow"
  | "outline"
  | "hollow"
  | "fire"
  | "ice";

export interface StyleDefinition {
  id: string;
  name: string;
  colors: string[];
  effect: StyleEffect;
}

export const CATEGORIES = [
  "All",
  "3D",
  "Neon",
  "Glow",
  "Metallic",
  "Gradient",
  "Fire",
  "Ice",
  "Shadow",
  "Outline"
] as const;

export type Category = (typeof CATEGORIES)[number];

export const RAINBOW_COLORS = [
  "#FF0040",
  "#FF8C00",
  "#FFD700",
  "#00E676",
  "#00B0FF",
  "#304FFE",
  "#AA00FF",
  "#FF1493",
];

export const PRESET_CUSTOM_COLORS = [
  "#FF1744",
  "#FF9100",
  "#FFEA00",
  "#00E676",
  "#00E5FF",
  "#2979FF",
  "#D500F9",
  "#FFFFFF",
  "#FFD700",
  "#C0C0C0",
];

export const SPECIAL_GOLU_STYLE: StyleDefinition = {
  id: "golu",
  name: "Golu (Special)",
  colors: ["#FFD700", "#FF1493", "#FFD700", "#FF69B4", "#FF8C00", "#FF1493"],
  effect: "neon",
};

export const ALL_STYLES: StyleDefinition[] = [
  {
    "id": "s1",
    "name": "3D Text",
    "colors": [
      "#FF0040",
      "#FF8C00",
      "#FFD700",
      "#00E676",
      "#00B0FF",
      "#304FFE",
      "#AA00FF"
    ],
    "effect": "3d"
  },
  {
    "id": "s2",
    "name": "3D Shadow",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "3d"
  },
  {
    "id": "s3",
    "name": "3D Metallic",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#C0C0C0",
      "#E8E8E8"
    ],
    "effect": "3d"
  },
  {
    "id": "s4",
    "name": "3D Gold",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "3d"
  },
  {
    "id": "s5",
    "name": "3D Silver",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#C0C0C0",
      "#E8E8E8"
    ],
    "effect": "3d"
  },
  {
    "id": "s6",
    "name": "3D Chrome",
    "colors": [
      "#E0E0E0",
      "#C0C0C0",
      "#FFFFFF",
      "#A0A0A0",
      "#D0D0D0"
    ],
    "effect": "3d"
  },
  {
    "id": "s7",
    "name": "3D Glass",
    "colors": [
      "#B0E0E6",
      "#AFEEEE",
      "#E0FFFF",
      "#B0C4DE"
    ],
    "effect": "3d"
  },
  {
    "id": "s8",
    "name": "3D Crystal",
    "colors": [
      "#B0E0E6",
      "#AFEEEE",
      "#E0FFFF",
      "#B0C4DE"
    ],
    "effect": "3d"
  },
  {
    "id": "s9",
    "name": "3D Diamond",
    "colors": [
      "#B9F2FF",
      "#FFFFFF",
      "#E0F7FF",
      "#FFFFFF",
      "#B9F2FF"
    ],
    "effect": "3d"
  },
  {
    "id": "s10",
    "name": "3D Neon",
    "colors": [
      "#9D00FF",
      "#BF00FF",
      "#AA00FF",
      "#7B00FF"
    ],
    "effect": "3d"
  },
  {
    "id": "s11",
    "name": "Gaming Logo",
    "colors": [
      "#9D00FF",
      "#BF00FF",
      "#AA00FF",
      "#7B00FF"
    ],
    "effect": "glow"
  },
  {
    "id": "s12",
    "name": "Pro Gamer",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "neon"
  },
  {
    "id": "s13",
    "name": "Esports",
    "colors": [
      "#00FFFF",
      "#FF00FF",
      "#00FF00",
      "#FFFF00"
    ],
    "effect": "neon"
  },
  {
    "id": "s14",
    "name": "Free Fire",
    "colors": [
      "#FF0000",
      "#FF4500",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "fire"
  },
  {
    "id": "s15",
    "name": "Battle",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s16",
    "name": "Warrior",
    "colors": [
      "#FF8C00",
      "#FFA500",
      "#FF6347",
      "#FF7F50"
    ],
    "effect": "glow"
  },
  {
    "id": "s17",
    "name": "King",
    "colors": [
      "#FFD700",
      "#FFC700",
      "#FFA500",
      "#FF8800"
    ],
    "effect": "metallic"
  },
  {
    "id": "s18",
    "name": "Royal",
    "colors": [
      "#4169E1",
      "#1E90FF",
      "#0000CD",
      "#6495ED"
    ],
    "effect": "glow"
  },
  {
    "id": "s19",
    "name": "Crown",
    "colors": [
      "#FFD700",
      "#DAA520",
      "#FFC125",
      "#EEC900"
    ],
    "effect": "metallic"
  },
  {
    "id": "s20",
    "name": "Luxury",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s21",
    "name": "Cursive",
    "colors": [
      "#800080",
      "#9932CC",
      "#8A2BE2",
      "#6A11CB"
    ],
    "effect": "gradient"
  },
  {
    "id": "s22",
    "name": "Calligraphy",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "gradient"
  },
  {
    "id": "s23",
    "name": "Handwriting",
    "colors": [
      "#0000FF",
      "#0000CD",
      "#4169E1",
      "#1E90FF"
    ],
    "effect": "gradient"
  },
  {
    "id": "s24",
    "name": "Signature",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s25",
    "name": "Brush",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "gradient"
  },
  {
    "id": "s26",
    "name": "Ink",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s27",
    "name": "Artistic",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "gradient"
  },
  {
    "id": "s28",
    "name": "Creative",
    "colors": [
      "#FF6B6B",
      "#FF8E53",
      "#FE6B8B",
      "#FF9966"
    ],
    "effect": "gradient"
  },
  {
    "id": "s29",
    "name": "Elegant",
    "colors": [
      "#4169E1",
      "#1E90FF",
      "#0000CD",
      "#6495ED"
    ],
    "effect": "gradient"
  },
  {
    "id": "s30",
    "name": "Stylish Script",
    "colors": [
      "#6A0DAD",
      "#8A2BE2",
      "#9370DB",
      "#7B68EE"
    ],
    "effect": "gradient"
  },
  {
    "id": "s31",
    "name": "Bold",
    "colors": [
      "#FFFFFF",
      "#F0F0F0",
      "#E0E0E0",
      "#FFFFFF"
    ],
    "effect": "shadow"
  },
  {
    "id": "s32",
    "name": "Heavy Bold",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "3d"
  },
  {
    "id": "s33",
    "name": "Thick Letter",
    "colors": [
      "#FFFFFF",
      "#F0F0F0",
      "#E0E0E0",
      "#FFFFFF"
    ],
    "effect": "shadow"
  },
  {
    "id": "s34",
    "name": "Block",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#A8A8A8"
    ],
    "effect": "shadow"
  },
  {
    "id": "s35",
    "name": "Outline",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "outline"
  },
  {
    "id": "s36",
    "name": "Double Outline",
    "colors": [
      "#9D00FF",
      "#BF00FF",
      "#AA00FF",
      "#7B00FF"
    ],
    "effect": "outline"
  },
  {
    "id": "s37",
    "name": "Hollow",
    "colors": [
      "#39FF14",
      "#7FFF00",
      "#00FA9A",
      "#3CB371"
    ],
    "effect": "hollow"
  },
  {
    "id": "s38",
    "name": "Bubble",
    "colors": [
      "#FF1493",
      "#FF69B4",
      "#FF6EB4",
      "#FFB6C1"
    ],
    "effect": "outline"
  },
  {
    "id": "s39",
    "name": "Rounded",
    "colors": [
      "#008080",
      "#20B2AA",
      "#48D1CC",
      "#40E0D0"
    ],
    "effect": "glow"
  },
  {
    "id": "s40",
    "name": "Square",
    "colors": [
      "#71797E",
      "#B5B5B5",
      "#979797",
      "#C0C0C0"
    ],
    "effect": "shadow"
  },
  {
    "id": "s41",
    "name": "Neon Glow",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "neon"
  },
  {
    "id": "s42",
    "name": "Electric",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "neon"
  },
  {
    "id": "s43",
    "name": "Lightning",
    "colors": [
      "#9D00FF",
      "#BF00FF",
      "#AA00FF",
      "#7B00FF"
    ],
    "effect": "neon"
  },
  {
    "id": "s44",
    "name": "Fire",
    "colors": [
      "#FF0000",
      "#FF4500",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "fire"
  },
  {
    "id": "s45",
    "name": "Ice",
    "colors": [
      "#A5F2F3",
      "#7FDBFF",
      "#39CCCC",
      "#2ECC40"
    ],
    "effect": "ice"
  },
  {
    "id": "s46",
    "name": "Water",
    "colors": [
      "#006994",
      "#0099CC",
      "#00CCCC",
      "#66CCFF"
    ],
    "effect": "ice"
  },
  {
    "id": "s47",
    "name": "Smoke",
    "colors": [
      "#7A7A7A",
      "#9A9A9A",
      "#5A5A5A",
      "#8A8A8A"
    ],
    "effect": "glow"
  },
  {
    "id": "s48",
    "name": "Galaxy",
    "colors": [
      "#6A0DAD",
      "#9370DB",
      "#BA55D3",
      "#DA70D6"
    ],
    "effect": "glow"
  },
  {
    "id": "s49",
    "name": "Space",
    "colors": [
      "#6A0DAD",
      "#8A2BE2",
      "#9370DB",
      "#7B68EE"
    ],
    "effect": "glow"
  },
  {
    "id": "s50",
    "name": "Cosmic",
    "colors": [
      "#6A0DAD",
      "#9370DB",
      "#BA55D3",
      "#DA70D6"
    ],
    "effect": "gradient"
  },
  {
    "id": "s51",
    "name": "Graffiti",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "glow"
  },
  {
    "id": "s52",
    "name": "Street Art",
    "colors": [
      "#FF6600",
      "#FF9900",
      "#FFCC00",
      "#FFAA00"
    ],
    "effect": "glow"
  },
  {
    "id": "s53",
    "name": "Spray Paint",
    "colors": [
      "#FF1493",
      "#FF69B4",
      "#FF6EB4",
      "#FFB6C1"
    ],
    "effect": "glow"
  },
  {
    "id": "s54",
    "name": "Urban",
    "colors": [
      "#00FFFF",
      "#FF00FF",
      "#00FF00",
      "#FFFF00"
    ],
    "effect": "neon"
  },
  {
    "id": "s55",
    "name": "Wild",
    "colors": [
      "#FF0040",
      "#FF8C00",
      "#FFD700",
      "#00E676",
      "#00B0FF",
      "#304FFE",
      "#AA00FF"
    ],
    "effect": "gradient"
  },
  {
    "id": "s56",
    "name": "Horror",
    "colors": [
      "#8B0000",
      "#FF0000",
      "#B22222",
      "#DC143C"
    ],
    "effect": "shadow"
  },
  {
    "id": "s57",
    "name": "Dark",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s58",
    "name": "Shadow",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s59",
    "name": "Ghost",
    "colors": [
      "#7A7A7A",
      "#9A9A9A",
      "#5A5A5A",
      "#8A8A8A"
    ],
    "effect": "glow"
  },
  {
    "id": "s60",
    "name": "Skull",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s61",
    "name": "Tattoo",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s62",
    "name": "Tribal",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s63",
    "name": "Vintage",
    "colors": [
      "#C4A676",
      "#B8956A",
      "#D4B582",
      "#A67C52"
    ],
    "effect": "gradient"
  },
  {
    "id": "s64",
    "name": "Retro",
    "colors": [
      "#FF8C00",
      "#FFA500",
      "#FF6347",
      "#FF7F50"
    ],
    "effect": "gradient"
  },
  {
    "id": "s65",
    "name": "Classic",
    "colors": [
      "#FFD700",
      "#FFC700",
      "#FFA500",
      "#FF8800"
    ],
    "effect": "gradient"
  },
  {
    "id": "s66",
    "name": "Modern",
    "colors": [
      "#6A11CB",
      "#8E2DE2",
      "#3f5efb",
      "#2575FC"
    ],
    "effect": "gradient"
  },
  {
    "id": "s67",
    "name": "Minimal",
    "colors": [
      "#FFFFFF",
      "#F0F0F0",
      "#E0E0E0",
      "#FFFFFF"
    ],
    "effect": "shadow"
  },
  {
    "id": "s68",
    "name": "Clean",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#A8A8A8"
    ],
    "effect": "shadow"
  },
  {
    "id": "s69",
    "name": "Simple",
    "colors": [
      "#FFFFFF",
      "#F0F0F0",
      "#E0E0E0",
      "#FFFFFF"
    ],
    "effect": "shadow"
  },
  {
    "id": "s70",
    "name": "Professional",
    "colors": [
      "#0000FF",
      "#0000CD",
      "#4169E1",
      "#1E90FF"
    ],
    "effect": "shadow"
  },
  {
    "id": "s71",
    "name": "Pixel",
    "colors": [
      "#00FF00",
      "#00CC00",
      "#009900",
      "#33FF33"
    ],
    "effect": "neon"
  },
  {
    "id": "s72",
    "name": "Digital",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "neon"
  },
  {
    "id": "s73",
    "name": "Tech",
    "colors": [
      "#00FFFF",
      "#FF00FF",
      "#00FF00",
      "#FFFF00"
    ],
    "effect": "neon"
  },
  {
    "id": "s74",
    "name": "Cyber",
    "colors": [
      "#00FFFF",
      "#FF00FF",
      "#00FF00",
      "#FFFF00"
    ],
    "effect": "neon"
  },
  {
    "id": "s75",
    "name": "Hologram",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "gradient"
  },
  {
    "id": "s76",
    "name": "Futuristic",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "neon"
  },
  {
    "id": "s77",
    "name": "Matrix",
    "colors": [
      "#00FF00",
      "#00CC00",
      "#009900",
      "#33FF33"
    ],
    "effect": "neon"
  },
  {
    "id": "s78",
    "name": "Robot",
    "colors": [
      "#71797E",
      "#B5B5B5",
      "#979797",
      "#C0C0C0"
    ],
    "effect": "metallic"
  },
  {
    "id": "s79",
    "name": "AI",
    "colors": [
      "#39FF14",
      "#7FFF00",
      "#00FA9A",
      "#3CB371"
    ],
    "effect": "neon"
  },
  {
    "id": "s80",
    "name": "Sci-Fi",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "neon"
  },
  {
    "id": "s81",
    "name": "Flame Logo",
    "colors": [
      "#FF0000",
      "#FF4500",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "fire"
  },
  {
    "id": "s82",
    "name": "Explosion",
    "colors": [
      "#FF4500",
      "#FF6347",
      "#FF8C00",
      "#FF0000"
    ],
    "effect": "fire"
  },
  {
    "id": "s83",
    "name": "Energy",
    "colors": [
      "#FF6600",
      "#FF9900",
      "#FFCC00",
      "#FFAA00"
    ],
    "effect": "neon"
  },
  {
    "id": "s84",
    "name": "Power",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s85",
    "name": "Superhero",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s86",
    "name": "Dragon",
    "colors": [
      "#FF4500",
      "#FF6347",
      "#FF8C00",
      "#FF0000"
    ],
    "effect": "fire"
  },
  {
    "id": "s87",
    "name": "Monster",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s88",
    "name": "Beast",
    "colors": [
      "#8B0000",
      "#FF0000",
      "#B22222",
      "#DC143C"
    ],
    "effect": "shadow"
  },
  {
    "id": "s89",
    "name": "Samurai",
    "colors": [
      "#8B0000",
      "#FF0000",
      "#B22222",
      "#DC143C"
    ],
    "effect": "shadow"
  },
  {
    "id": "s90",
    "name": "Ninja",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s91",
    "name": "Rainbow",
    "colors": [
      "#FF0040",
      "#FF8C00",
      "#FFD700",
      "#00E676",
      "#00B0FF",
      "#304FFE",
      "#AA00FF"
    ],
    "effect": "gradient"
  },
  {
    "id": "s92",
    "name": "Color Gradient",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "gradient"
  },
  {
    "id": "s93",
    "name": "RGB",
    "colors": [
      "#00FFFF",
      "#FF00FF",
      "#00FF00",
      "#FFFF00"
    ],
    "effect": "neon"
  },
  {
    "id": "s94",
    "name": "Colorful Glow",
    "colors": [
      "#FF0040",
      "#FF8C00",
      "#FFD700",
      "#00E676",
      "#00B0FF",
      "#304FFE",
      "#AA00FF"
    ],
    "effect": "glow"
  },
  {
    "id": "s95",
    "name": "Metallic Rainbow",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "metallic"
  },
  {
    "id": "s96",
    "name": "Diamond Shine",
    "colors": [
      "#B9F2FF",
      "#FFFFFF",
      "#E0F7FF",
      "#FFFFFF",
      "#B9F2FF"
    ],
    "effect": "metallic"
  },
  {
    "id": "s97",
    "name": "Glitter",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "gradient"
  },
  {
    "id": "s98",
    "name": "Sparkle",
    "colors": [
      "#FF1493",
      "#FF69B4",
      "#FF6EB4",
      "#FFB6C1"
    ],
    "effect": "glow"
  },
  {
    "id": "s99",
    "name": "Luxury Gold",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s100",
    "name": "Royal Blue",
    "colors": [
      "#4169E1",
      "#1E90FF",
      "#0000CD",
      "#6495ED"
    ],
    "effect": "glow"
  },
  {
    "id": "s101",
    "name": "Red Glow",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s102",
    "name": "Blue Glow",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "glow"
  },
  {
    "id": "s103",
    "name": "Green Glow",
    "colors": [
      "#39FF14",
      "#7FFF00",
      "#00FA9A",
      "#3CB371"
    ],
    "effect": "glow"
  },
  {
    "id": "s104",
    "name": "Purple Glow",
    "colors": [
      "#9D00FF",
      "#BF00FF",
      "#AA00FF",
      "#7B00FF"
    ],
    "effect": "glow"
  },
  {
    "id": "s105",
    "name": "Pink Glow",
    "colors": [
      "#FF1493",
      "#FF69B4",
      "#FF6EB4",
      "#FFB6C1"
    ],
    "effect": "glow"
  },
  {
    "id": "s106",
    "name": "Orange Fire",
    "colors": [
      "#FF6600",
      "#FF9900",
      "#FFCC00",
      "#FFAA00"
    ],
    "effect": "fire"
  },
  {
    "id": "s107",
    "name": "Ice Blue",
    "colors": [
      "#A5F2F3",
      "#7FDBFF",
      "#39CCCC",
      "#2ECC40"
    ],
    "effect": "ice"
  },
  {
    "id": "s108",
    "name": "Dark Neon",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "neon"
  },
  {
    "id": "s109",
    "name": "Laser",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "neon"
  },
  {
    "id": "s110",
    "name": "Light Beam",
    "colors": [
      "#FF6600",
      "#FF9900",
      "#FFCC00",
      "#FFAA00"
    ],
    "effect": "glow"
  },
  {
    "id": "s111",
    "name": "Chrome 3D",
    "colors": [
      "#E0E0E0",
      "#C0C0C0",
      "#FFFFFF",
      "#A0A0A0",
      "#D0D0D0"
    ],
    "effect": "metallic"
  },
  {
    "id": "s112",
    "name": "Gold Foil",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s113",
    "name": "Silver Metal",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#C0C0C0",
      "#E8E8E8"
    ],
    "effect": "metallic"
  },
  {
    "id": "s114",
    "name": "Bronze",
    "colors": [
      "#CD7F32",
      "#B87333",
      "#A0522D",
      "#8B4513"
    ],
    "effect": "metallic"
  },
  {
    "id": "s115",
    "name": "Rust Metal",
    "colors": [
      "#B7410E",
      "#8B4000",
      "#CB6D2E",
      "#A0522D"
    ],
    "effect": "metallic"
  },
  {
    "id": "s116",
    "name": "Steel",
    "colors": [
      "#71797E",
      "#B5B5B5",
      "#979797",
      "#C0C0C0"
    ],
    "effect": "metallic"
  },
  {
    "id": "s117",
    "name": "Iron",
    "colors": [
      "#3D3D3D",
      "#5A5A5A",
      "#7A7A7A",
      "#4A4A4A"
    ],
    "effect": "metallic"
  },
  {
    "id": "s118",
    "name": "Diamond Cut",
    "colors": [
      "#B9F2FF",
      "#FFFFFF",
      "#E0F7FF",
      "#FFFFFF",
      "#B9F2FF"
    ],
    "effect": "metallic"
  },
  {
    "id": "s119",
    "name": "Jewel",
    "colors": [
      "#9D00FF",
      "#BF00FF",
      "#AA00FF",
      "#7B00FF"
    ],
    "effect": "metallic"
  },
  {
    "id": "s120",
    "name": "Gemstone",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "metallic"
  },
  {
    "id": "s121",
    "name": "Mirror",
    "colors": [
      "#E8E8E8",
      "#F8F8F8",
      "#D8D8D8",
      "#FFFFFF"
    ],
    "effect": "metallic"
  },
  {
    "id": "s122",
    "name": "Reflection",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#C0C0C0",
      "#E8E8E8"
    ],
    "effect": "metallic"
  },
  {
    "id": "s123",
    "name": "Glass Reflection",
    "colors": [
      "#B0E0E6",
      "#AFEEEE",
      "#E0FFFF",
      "#B0C4DE"
    ],
    "effect": "metallic"
  },
  {
    "id": "s124",
    "name": "Transparent",
    "colors": [
      "#B0E0E6",
      "#AFEEEE",
      "#E0FFFF",
      "#B0C4DE"
    ],
    "effect": "glow"
  },
  {
    "id": "s125",
    "name": "Crystal Glass",
    "colors": [
      "#B0E0E6",
      "#AFEEEE",
      "#E0FFFF",
      "#B0C4DE"
    ],
    "effect": "metallic"
  },
  {
    "id": "s126",
    "name": "Liquid",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "gradient"
  },
  {
    "id": "s127",
    "name": "Water Drop",
    "colors": [
      "#006994",
      "#0099CC",
      "#00CCCC",
      "#66CCFF"
    ],
    "effect": "ice"
  },
  {
    "id": "s128",
    "name": "Wave",
    "colors": [
      "#006994",
      "#0099CC",
      "#00CCCC",
      "#66CCFF"
    ],
    "effect": "gradient"
  },
  {
    "id": "s129",
    "name": "Ocean",
    "colors": [
      "#006994",
      "#0099CC",
      "#00CCCC",
      "#66CCFF"
    ],
    "effect": "ice"
  },
  {
    "id": "s130",
    "name": "Rain",
    "colors": [
      "#A5F2F3",
      "#7FDBFF",
      "#39CCCC",
      "#2ECC40"
    ],
    "effect": "ice"
  },
  {
    "id": "s131",
    "name": "Nature",
    "colors": [
      "#228B22",
      "#006400",
      "#32CD32",
      "#90EE90"
    ],
    "effect": "glow"
  },
  {
    "id": "s132",
    "name": "Leaf",
    "colors": [
      "#3CB371",
      "#2E8B57",
      "#90EE90",
      "#6B8E23"
    ],
    "effect": "glow"
  },
  {
    "id": "s133",
    "name": "Forest",
    "colors": [
      "#228B22",
      "#006400",
      "#32CD32",
      "#90EE90"
    ],
    "effect": "glow"
  },
  {
    "id": "s134",
    "name": "Earth",
    "colors": [
      "#228B22",
      "#006400",
      "#32CD32",
      "#90EE90"
    ],
    "effect": "gradient"
  },
  {
    "id": "s135",
    "name": "Stone",
    "colors": [
      "#8B8680",
      "#736F66",
      "#5D574F",
      "#9B9590"
    ],
    "effect": "shadow"
  },
  {
    "id": "s136",
    "name": "Rock",
    "colors": [
      "#8B8680",
      "#736F66",
      "#5D574F",
      "#9B9590"
    ],
    "effect": "shadow"
  },
  {
    "id": "s137",
    "name": "Sand",
    "colors": [
      "#C2B280",
      "#D4C596",
      "#E8D8A0",
      "#B8A060"
    ],
    "effect": "gradient"
  },
  {
    "id": "s138",
    "name": "Wood",
    "colors": [
      "#8B4513",
      "#A0522D",
      "#CD853F",
      "#DEB887"
    ],
    "effect": "gradient"
  },
  {
    "id": "s139",
    "name": "Firewood",
    "colors": [
      "#8B4513",
      "#A0522D",
      "#CD853F",
      "#DEB887"
    ],
    "effect": "shadow"
  },
  {
    "id": "s140",
    "name": "Natural 3D",
    "colors": [
      "#228B22",
      "#006400",
      "#32CD32",
      "#90EE90"
    ],
    "effect": "3d"
  },
  {
    "id": "s141",
    "name": "Cartoon",
    "colors": [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A"
    ],
    "effect": "outline"
  },
  {
    "id": "s142",
    "name": "Comic",
    "colors": [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A"
    ],
    "effect": "outline"
  },
  {
    "id": "s143",
    "name": "Anime",
    "colors": [
      "#FF1493",
      "#FF69B4",
      "#FF6EB4",
      "#FFB6C1"
    ],
    "effect": "glow"
  },
  {
    "id": "s144",
    "name": "Manga",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s145",
    "name": "Character",
    "colors": [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A"
    ],
    "effect": "outline"
  },
  {
    "id": "s146",
    "name": "Mascot",
    "colors": [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A"
    ],
    "effect": "outline"
  },
  {
    "id": "s147",
    "name": "Cute",
    "colors": [
      "#FF1493",
      "#FF69B4",
      "#FF6EB4",
      "#FFB6C1"
    ],
    "effect": "glow"
  },
  {
    "id": "s148",
    "name": "Funny",
    "colors": [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A"
    ],
    "effect": "outline"
  },
  {
    "id": "s149",
    "name": "Kids",
    "colors": [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A"
    ],
    "effect": "outline"
  },
  {
    "id": "s150",
    "name": "Cartoon Logo",
    "colors": [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A"
    ],
    "effect": "outline"
  },
  {
    "id": "s151",
    "name": "Luxury Logo",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s152",
    "name": "Brand",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#C0C0C0",
      "#E8E8E8"
    ],
    "effect": "metallic"
  },
  {
    "id": "s153",
    "name": "Premium",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s154",
    "name": "VIP",
    "colors": [
      "#FFD700",
      "#FFC700",
      "#FFA500",
      "#FF8800"
    ],
    "effect": "metallic"
  },
  {
    "id": "s155",
    "name": "Diamond VIP",
    "colors": [
      "#B9F2FF",
      "#FFFFFF",
      "#E0F7FF",
      "#FFFFFF",
      "#B9F2FF"
    ],
    "effect": "metallic"
  },
  {
    "id": "s156",
    "name": "Elite",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#C0C0C0",
      "#E8E8E8"
    ],
    "effect": "metallic"
  },
  {
    "id": "s157",
    "name": "Champion",
    "colors": [
      "#FFD700",
      "#FFC700",
      "#FFA500",
      "#FF8800"
    ],
    "effect": "metallic"
  },
  {
    "id": "s158",
    "name": "Winner",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s159",
    "name": "Legend",
    "colors": [
      "#FFD700",
      "#DAA520",
      "#FFC125",
      "#EEC900"
    ],
    "effect": "metallic"
  },
  {
    "id": "s160",
    "name": "Hero",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s161",
    "name": "YouTube Logo",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s162",
    "name": "Shorts",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s163",
    "name": "Channel Logo",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s164",
    "name": "Creator",
    "colors": [
      "#FF1493",
      "#FF69B4",
      "#FF6EB4",
      "#FFB6C1"
    ],
    "effect": "glow"
  },
  {
    "id": "s165",
    "name": "Vlogger",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "glow"
  },
  {
    "id": "s166",
    "name": "Social Media",
    "colors": [
      "#00FFFF",
      "#FF00FF",
      "#00FF00",
      "#FFFF00"
    ],
    "effect": "neon"
  },
  {
    "id": "s167",
    "name": "Profile DP",
    "colors": [
      "#800080",
      "#9932CC",
      "#8A2BE2",
      "#6A11CB"
    ],
    "effect": "gradient"
  },
  {
    "id": "s168",
    "name": "Avatar",
    "colors": [
      "#6A11CB",
      "#8E2DE2",
      "#3f5efb",
      "#2575FC"
    ],
    "effect": "gradient"
  },
  {
    "id": "s169",
    "name": "Thumbnail",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "glow"
  },
  {
    "id": "s170",
    "name": "Banner",
    "colors": [
      "#6A11CB",
      "#8E2DE2",
      "#3f5efb",
      "#2575FC"
    ],
    "effect": "gradient"
  },
  {
    "id": "s171",
    "name": "Speed",
    "colors": [
      "#FF6600",
      "#FF9900",
      "#FFCC00",
      "#FFAA00"
    ],
    "effect": "glow"
  },
  {
    "id": "s172",
    "name": "Racing",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s173",
    "name": "Car",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s174",
    "name": "Bike",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s175",
    "name": "Sports",
    "colors": [
      "#FF8C00",
      "#FFA500",
      "#FF6347",
      "#FF7F50"
    ],
    "effect": "glow"
  },
  {
    "id": "s176",
    "name": "Football",
    "colors": [
      "#008000",
      "#00FF00",
      "#32CD32",
      "#228B22"
    ],
    "effect": "glow"
  },
  {
    "id": "s177",
    "name": "Cricket",
    "colors": [
      "#0000FF",
      "#0000CD",
      "#4169E1",
      "#1E90FF"
    ],
    "effect": "glow"
  },
  {
    "id": "s178",
    "name": "Action",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#B22222",
      "#8B0000"
    ],
    "effect": "glow"
  },
  {
    "id": "s179",
    "name": "Adventure",
    "colors": [
      "#228B22",
      "#006400",
      "#32CD32",
      "#90EE90"
    ],
    "effect": "glow"
  },
  {
    "id": "s180",
    "name": "Extreme",
    "colors": [
      "#FF4500",
      "#FF6347",
      "#FF8C00",
      "#FF0000"
    ],
    "effect": "fire"
  },
  {
    "id": "s181",
    "name": "Ancient",
    "colors": [
      "#CD7F32",
      "#B87333",
      "#A0522D",
      "#8B4513"
    ],
    "effect": "metallic"
  },
  {
    "id": "s182",
    "name": "Medieval",
    "colors": [
      "#3D3D3D",
      "#5A5A5A",
      "#7A7A7A",
      "#4A4A4A"
    ],
    "effect": "metallic"
  },
  {
    "id": "s183",
    "name": "Warrior King",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s184",
    "name": "Mythology",
    "colors": [
      "#6A0DAD",
      "#9370DB",
      "#BA55D3",
      "#DA70D6"
    ],
    "effect": "glow"
  },
  {
    "id": "s185",
    "name": "Temple",
    "colors": [
      "#8B8680",
      "#736F66",
      "#5D574F",
      "#9B9590"
    ],
    "effect": "shadow"
  },
  {
    "id": "s186",
    "name": "Golden Temple",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s187",
    "name": "Royal Palace",
    "colors": [
      "#FFD700",
      "#DAA520",
      "#FFC125",
      "#EEC900"
    ],
    "effect": "metallic"
  },
  {
    "id": "s188",
    "name": "Emperor",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s189",
    "name": "Ancient Gold",
    "colors": [
      "#CD7F32",
      "#B87333",
      "#A0522D",
      "#8B4513"
    ],
    "effect": "metallic"
  },
  {
    "id": "s190",
    "name": "Historical",
    "colors": [
      "#C4A676",
      "#B8956A",
      "#D4B582",
      "#A67C52"
    ],
    "effect": "gradient"
  },
  {
    "id": "s191",
    "name": "Smoke 3D",
    "colors": [
      "#7A7A7A",
      "#9A9A9A",
      "#5A5A5A",
      "#8A8A8A"
    ],
    "effect": "3d"
  },
  {
    "id": "s192",
    "name": "Dust",
    "colors": [
      "#C2B280",
      "#D4C596",
      "#E8D8A0",
      "#B8A060"
    ],
    "effect": "glow"
  },
  {
    "id": "s193",
    "name": "Sand Storm",
    "colors": [
      "#C2B280",
      "#D4C596",
      "#E8D8A0",
      "#B8A060"
    ],
    "effect": "glow"
  },
  {
    "id": "s194",
    "name": "Wind",
    "colors": [
      "#A5F2F3",
      "#7FDBFF",
      "#39CCCC",
      "#2ECC40"
    ],
    "effect": "glow"
  },
  {
    "id": "s195",
    "name": "Cloud",
    "colors": [
      "#FFFFFF",
      "#F0F0F0",
      "#E0E0E0",
      "#FFFFFF"
    ],
    "effect": "glow"
  },
  {
    "id": "s196",
    "name": "Sky",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "glow"
  },
  {
    "id": "s197",
    "name": "Moon",
    "colors": [
      "#FFFFFF",
      "#F0F0F0",
      "#E0E0E0",
      "#FFFFFF"
    ],
    "effect": "glow"
  },
  {
    "id": "s198",
    "name": "Star",
    "colors": [
      "#FF6600",
      "#FF9900",
      "#FFCC00",
      "#FFAA00"
    ],
    "effect": "glow"
  },
  {
    "id": "s199",
    "name": "Galaxy Neon",
    "colors": [
      "#6A0DAD",
      "#9370DB",
      "#BA55D3",
      "#DA70D6"
    ],
    "effect": "neon"
  },
  {
    "id": "s200",
    "name": "Universe",
    "colors": [
      "#6A0DAD",
      "#9370DB",
      "#BA55D3",
      "#DA70D6"
    ],
    "effect": "gradient"
  },
  {
    "id": "s201",
    "name": "Abstract",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "gradient"
  },
  {
    "id": "s202",
    "name": "Creative Art",
    "colors": [
      "#FF6B6B",
      "#FF8E53",
      "#FE6B8B",
      "#FF9966"
    ],
    "effect": "gradient"
  },
  {
    "id": "s203",
    "name": "Modern Art",
    "colors": [
      "#6A11CB",
      "#8E2DE2",
      "#3f5efb",
      "#2575FC"
    ],
    "effect": "gradient"
  },
  {
    "id": "s204",
    "name": "Paint",
    "colors": [
      "#FF0040",
      "#FF8C00",
      "#FFD700",
      "#00E676",
      "#00B0FF",
      "#304FFE",
      "#AA00FF"
    ],
    "effect": "gradient"
  },
  {
    "id": "s205",
    "name": "Watercolor",
    "colors": [
      "#006994",
      "#0099CC",
      "#00CCCC",
      "#66CCFF"
    ],
    "effect": "gradient"
  },
  {
    "id": "s206",
    "name": "Oil Paint",
    "colors": [
      "#FF0000",
      "#FF4500",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "gradient"
  },
  {
    "id": "s207",
    "name": "Pencil",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s208",
    "name": "Sketch",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "hollow"
  },
  {
    "id": "s209",
    "name": "Drawing",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s210",
    "name": "Hand Drawn",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "hollow"
  },
  {
    "id": "s211",
    "name": "Sticker",
    "colors": [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A"
    ],
    "effect": "outline"
  },
  {
    "id": "s212",
    "name": "Badge",
    "colors": [
      "#FFD700",
      "#FFC700",
      "#FFA500",
      "#FF8800"
    ],
    "effect": "outline"
  },
  {
    "id": "s213",
    "name": "Emblem",
    "colors": [
      "#CD7F32",
      "#B87333",
      "#A0522D",
      "#8B4513"
    ],
    "effect": "outline"
  },
  {
    "id": "s214",
    "name": "Shield",
    "colors": [
      "#71797E",
      "#B5B5B5",
      "#979797",
      "#C0C0C0"
    ],
    "effect": "outline"
  },
  {
    "id": "s215",
    "name": "Logo Mark",
    "colors": [
      "#6A11CB",
      "#8E2DE2",
      "#3f5efb",
      "#2575FC"
    ],
    "effect": "outline"
  },
  {
    "id": "s216",
    "name": "Circle Logo",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "outline"
  },
  {
    "id": "s217",
    "name": "Square Logo",
    "colors": [
      "#71797E",
      "#B5B5B5",
      "#979797",
      "#C0C0C0"
    ],
    "effect": "outline"
  },
  {
    "id": "s218",
    "name": "Frame",
    "colors": [
      "#FFD700",
      "#FFC700",
      "#FFA500",
      "#FF8800"
    ],
    "effect": "outline"
  },
  {
    "id": "s219",
    "name": "Border",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#A8A8A8"
    ],
    "effect": "outline"
  },
  {
    "id": "s220",
    "name": "Decoration",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "outline"
  },
  {
    "id": "s221",
    "name": "Gothic",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s222",
    "name": "Medieval Font",
    "colors": [
      "#3D3D3D",
      "#5A5A5A",
      "#7A7A7A",
      "#4A4A4A"
    ],
    "effect": "shadow"
  },
  {
    "id": "s223",
    "name": "Old English",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "shadow"
  },
  {
    "id": "s224",
    "name": "Horror Text",
    "colors": [
      "#8B0000",
      "#FF0000",
      "#B22222",
      "#DC143C"
    ],
    "effect": "shadow"
  },
  {
    "id": "s225",
    "name": "Blood",
    "colors": [
      "#8B0000",
      "#FF0000",
      "#B22222",
      "#DC143C"
    ],
    "effect": "fire"
  },
  {
    "id": "s226",
    "name": "Zombie",
    "colors": [
      "#228B22",
      "#006400",
      "#32CD32",
      "#90EE90"
    ],
    "effect": "shadow"
  },
  {
    "id": "s227",
    "name": "Vampire",
    "colors": [
      "#8B0000",
      "#FF0000",
      "#B22222",
      "#DC143C"
    ],
    "effect": "shadow"
  },
  {
    "id": "s228",
    "name": "Dark Fantasy",
    "colors": [
      "#6A0DAD",
      "#8A2BE2",
      "#9370DB",
      "#7B68EE"
    ],
    "effect": "shadow"
  },
  {
    "id": "s229",
    "name": "Magic",
    "colors": [
      "#9D00FF",
      "#BF00FF",
      "#AA00FF",
      "#7B00FF"
    ],
    "effect": "neon"
  },
  {
    "id": "s230",
    "name": "Wizard",
    "colors": [
      "#6A0DAD",
      "#9370DB",
      "#BA55D3",
      "#DA70D6"
    ],
    "effect": "neon"
  },
  {
    "id": "s231",
    "name": "Neon Tube",
    "colors": [
      "#FF1493",
      "#FF69B4",
      "#FF6EB4",
      "#FFB6C1"
    ],
    "effect": "neon"
  },
  {
    "id": "s232",
    "name": "LED",
    "colors": [
      "#39FF14",
      "#7FFF00",
      "#00FA9A",
      "#3CB371"
    ],
    "effect": "neon"
  },
  {
    "id": "s233",
    "name": "Cyberpunk",
    "colors": [
      "#00FFFF",
      "#FF00FF",
      "#00FF00",
      "#FFFF00"
    ],
    "effect": "neon"
  },
  {
    "id": "s234",
    "name": "Glitch",
    "colors": [
      "#FF0000",
      "#00FF00",
      "#0000FF",
      "#FFFFFF"
    ],
    "effect": "neon"
  },
  {
    "id": "s235",
    "name": "Digital Pixel",
    "colors": [
      "#00FF00",
      "#00CC00",
      "#009900",
      "#33FF33"
    ],
    "effect": "neon"
  },
  {
    "id": "s236",
    "name": "Arcade",
    "colors": [
      "#00FFFF",
      "#FF00FF",
      "#00FF00",
      "#FFFF00"
    ],
    "effect": "neon"
  },
  {
    "id": "s237",
    "name": "Game HUD",
    "colors": [
      "#39FF14",
      "#7FFF00",
      "#00FA9A",
      "#3CB371"
    ],
    "effect": "neon"
  },
  {
    "id": "s238",
    "name": "Tech Logo",
    "colors": [
      "#00FFFF",
      "#00BFFF",
      "#1E90FF",
      "#4169E1"
    ],
    "effect": "neon"
  },
  {
    "id": "s239",
    "name": "Coding",
    "colors": [
      "#00FF00",
      "#00CC00",
      "#009900",
      "#33FF33"
    ],
    "effect": "neon"
  },
  {
    "id": "s240",
    "name": "Hacker",
    "colors": [
      "#39FF14",
      "#7FFF00",
      "#00FA9A",
      "#3CB371"
    ],
    "effect": "neon"
  },
  {
    "id": "s241",
    "name": "Ultra 3D",
    "colors": [
      "#FF0040",
      "#FF8C00",
      "#FFD700",
      "#00E676",
      "#00B0FF",
      "#304FFE",
      "#AA00FF"
    ],
    "effect": "3d"
  },
  {
    "id": "s242",
    "name": "Ultra Realistic",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "3d"
  },
  {
    "id": "s243",
    "name": "Cinematic",
    "colors": [
      "#333333",
      "#555555",
      "#1a1a1a",
      "#666666"
    ],
    "effect": "3d"
  },
  {
    "id": "s244",
    "name": "Movie Title",
    "colors": [
      "#FFD700",
      "#FFA500",
      "#FFD700",
      "#FF8C00",
      "#FFD700"
    ],
    "effect": "metallic"
  },
  {
    "id": "s245",
    "name": "Poster",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "gradient"
  },
  {
    "id": "s246",
    "name": "Intro Logo",
    "colors": [
      "#6A11CB",
      "#8E2DE2",
      "#3f5efb",
      "#2575FC"
    ],
    "effect": "gradient"
  },
  {
    "id": "s247",
    "name": "Animation",
    "colors": [
      "#FF0040",
      "#FF8C00",
      "#FFD700",
      "#00E676",
      "#00B0FF",
      "#304FFE",
      "#AA00FF"
    ],
    "effect": "gradient"
  },
  {
    "id": "s248",
    "name": "Motion Graphics",
    "colors": [
      "#FF6B6B",
      "#FF8E53",
      "#FE6B8B",
      "#FF9966"
    ],
    "effect": "gradient"
  },
  {
    "id": "s249",
    "name": "Professional Logo",
    "colors": [
      "#E8E8E8",
      "#C0C0C0",
      "#FFFFFF",
      "#C0C0C0",
      "#E8E8E8"
    ],
    "effect": "metallic"
  },
  {
    "id": "s250",
    "name": "Custom Unique",
    "colors": [
      "#FF1744",
      "#FF9100",
      "#FFEA00",
      "#00E676",
      "#00E5FF",
      "#2979FF",
      "#D500F9"
    ],
    "effect": "gradient"
  },
  {
    "id": "s251",
    "name": "Coffee Royal",
    "colors": [
      "#FF0000",
      "#DC143C",
      "#8B0000",
      "#A52A2A",
      "#D2691E"
    ],
    "effect": "gradient"
  }
];

export function getStylesByCategory(category: string): StyleDefinition[] {
  if (category === "All") return ALL_STYLES;
  const t = category.toLowerCase();
  return ALL_STYLES.filter((r) => {
    if (t === "3d") return r.effect === "3d";
    if (t === "neon") return r.effect === "neon";
    if (t === "glow") return r.effect === "glow";
    if (t === "metallic") return r.effect === "metallic";
    if (t === "gradient") return r.effect === "gradient";
    if (t === "fire") return r.effect === "fire";
    if (t === "ice") return r.effect === "ice";
    if (t === "shadow") return r.effect === "shadow";
    if (t === "outline") return r.effect === "outline" || r.effect === "hollow";
    return true;
  });
}

export interface RenderStyleOptions {
  glowStrength?: number;
  shadow?: boolean;
}

export interface StyledChar {
  ch: string;
  style: React.CSSProperties;
}

export function computeCharacterStyles(
  text: string,
  styleDef: StyleDefinition,
  options: RenderStyleOptions = {}
): StyledChar[] {
  if (!text) return [];
  const { glowStrength = 1, shadow = false } = options;

  return text.split("").map((ch, idx) => {
    const c = styleDef.colors[idx % styleDef.colors.length];
    const s: React.CSSProperties = {};

    switch (styleDef.effect) {
      case "neon": {
        const h = 8 * glowStrength;
        s.color = c;
        s.textShadow = `0 0 ${h}px ${c}, 0 0 ${h * 2}px ${c}, 0 0 ${h * 3}px ${c}`;
        break;
      }
      case "glow": {
        const h = 4 * glowStrength;
        s.color = c;
        s.textShadow = `0 0 ${h}px ${c}, 0 0 ${h * 2}px ${c}`;
        break;
      }
      case "3d": {
        s.color = c;
        s.textShadow =
          "1px 1px 0 rgba(0,0,0,0.8), 2px 2px 0 rgba(0,0,0,0.7), 3px 3px 0 rgba(0,0,0,0.6), 4px 4px 0 rgba(0,0,0,0.5), 5px 5px 0 rgba(0,0,0,0.4), 6px 6px 10px rgba(0,0,0,0.5)";
        break;
      }
      case "metallic": {
        const joined = styleDef.colors.join(", ");
        s.display = "inline-block";
        s.background = `linear-gradient(135deg, ${joined})`;
        s.WebkitBackgroundClip = "text";
        (s as any).backgroundClip = "text";
        s.WebkitTextFillColor = "transparent";
        s.textShadow = "0 1px 2px rgba(0,0,0,0.4)";
        break;
      }
      case "gradient": {
        const joined = styleDef.colors.join(", ");
        s.display = "inline-block";
        s.background = `linear-gradient(90deg, ${joined})`;
        s.WebkitBackgroundClip = "text";
        (s as any).backgroundClip = "text";
        s.WebkitTextFillColor = "transparent";
        break;
      }
      case "shadow": {
        s.color = c;
        s.textShadow = "3px 3px 6px rgba(0,0,0,0.7)";
        break;
      }
      case "outline": {
        s.color = c;
        (s as any).WebkitTextStroke = "1.5px rgba(0,0,0,0.8)";
        s.textShadow = "2px 2px 4px rgba(0,0,0,0.5)";
        break;
      }
      case "hollow": {
        s.color = "transparent";
        (s as any).WebkitTextStroke = `2px ${c}`;
        break;
      }
      case "fire": {
        s.color = c;
        s.textShadow = `0 0 6px ${c}, 0 0 12px #FF4500, 0 0 20px #FF0000, 0 -2px 8px #FFD700`;
        break;
      }
      case "ice": {
        s.color = c;
        s.textShadow = `0 0 6px ${c}, 0 0 12px #7FDBFF, 0 0 20px #00BFFF, 0 0 30px rgba(0,191,255,0.3)`;
        break;
      }
      default:
        s.color = c;
    }

    if (shadow && styleDef.effect !== "metallic" && styleDef.effect !== "gradient") {
      s.textShadow =
        (s.textShadow ? s.textShadow + ", " : "") + "2px 2px 4px rgba(0,0,0,0.7)";
    }

    return { ch, style: s };
  });
}
