/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ALL_STYLES, StyleDefinition } from './data/neonStyles';
import { Header } from './components/Header';
import { BottomNav, NavTab } from './components/BottomNav';
import { SidebarDrawer } from './components/SidebarDrawer';
import { HomeTab } from './components/HomeTab';
import { StylesTab } from './components/StylesTab';
import { FavoritesTab } from './components/FavoritesTab';
import { SettingsTab } from './components/SettingsTab';
import { AnalyticsTab } from './components/AnalyticsTab';
import { getFavorites } from './utils/storage';

const POPULAR_NAMES = [
  'Sourabh',
  'GamerX',
  'RoyalKing',
  'Aarav',
  'Priya',
  'Ananya',
  'Vikram',
  'Dev',
  'Shadow',
  'BadBoy',
  'Queen',
  'StarBoy',
  'Kabir',
  'Rohan',
];

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [favoritesSubTab, setFavoritesSubTab] = useState<'favorites' | 'history'>('favorites');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [selectedStyle, setSelectedStyle] = useState<StyleDefinition>(ALL_STYLES[0]);
  const [fontSize, setFontSize] = useState<number>(34);
  const [glowStrength, setGlowStrength] = useState<number>(1.2);
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [language, setLanguage] = useState<'en' | 'hi'>('hi');
  const [favoritesCount, setFavoritesCount] = useState<number>(0);

  // Sync favorites count
  useEffect(() => {
    const updateCount = () => {
      const favs = getFavorites();
      setFavoritesCount(favs.length);
    };
    updateCount();
    const interval = setInterval(updateCount, 1500);
    return () => clearInterval(interval);
  }, []);

  const handlePickRandomName = () => {
    const randomName = POPULAR_NAMES[Math.floor(Math.random() * POPULAR_NAMES.length)];
    const randomStyle = ALL_STYLES[Math.floor(Math.random() * ALL_STYLES.length)];
    setSelectedStyle(randomStyle);
    setCurrentTab('home');

    // Trigger name in input if on home
    const input = document.querySelector('input[placeholder="Enter your name"]') as HTMLInputElement;
    if (input) {
      input.value = randomName;
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  };

  const handleNavigate = (tab: NavTab, extra?: { subTab?: 'favorites' | 'history' }) => {
    setCurrentTab(tab);
    if (extra?.subTab) {
      setFavoritesSubTab(extra.subTab);
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col text-white selection:bg-purple-500 selection:text-white ${
        darkMode ? 'bg-[#0D0D0D]' : 'bg-[#121216]'
      }`}
      style={{ background: '#0D0D0D' }}
    >
      {/* Top Header */}
      <Header
        onMenu={() => setIsDrawerOpen(true)}
        onRandomName={handlePickRandomName}
      />

      {/* Main Content Area */}
      <main className="flex-1 px-4 pb-28 pt-2 overflow-y-auto">
        {currentTab === 'home' && (
          <HomeTab
            onNavigate={handleNavigate}
            selectedStyle={selectedStyle}
            onSelectStyle={setSelectedStyle}
            fontSize={fontSize}
            glowStrength={glowStrength}
          />
        )}

        {currentTab === 'styles' && (
          <StylesTab
            currentStyle={selectedStyle}
            onSelectStyle={(st) => {
              setSelectedStyle(st);
            }}
            previewName="Sourabh"
            glowStrength={glowStrength}
          />
        )}

        {currentTab === 'favorites' && (
          <FavoritesTab
            initialSubTab={favoritesSubTab}
            onSelectStyle={(st) => {
              setSelectedStyle(st);
              setCurrentTab('home');
            }}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsTab
            fontSize={fontSize}
            setFontSize={setFontSize}
            glowStrength={glowStrength}
            setGlowStrength={setGlowStrength}
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            language={language}
            setLanguage={setLanguage}
          />
        )}

        {currentTab === 'analytics' && (
          <AnalyticsTab
            onSelectStyle={(st) => {
              setSelectedStyle(st);
              setCurrentTab('home');
            }}
          />
        )}
      </main>

      {/* Bottom Tab Bar */}
      <BottomNav
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        favoritesCount={favoritesCount}
      />

      {/* Sidebar Drawer */}
      <SidebarDrawer
        isOpen={isDrawerOpen}
        onClose={() => setIsDrawerOpen(false)}
        onNavigate={handleNavigate}
      />
    </div>
  );
}
