export interface SavedNameItem {
  id: string;
  name: string;
  styleId: string;
  unicodeText?: string;
  ts: number;
}

const FAVORITES_KEY = 'ncg_favorites';
const HISTORY_KEY = 'ncg_history';

export function getFavorites(): SavedNameItem[] {
  try {
    return JSON.parse(localStorage.getItem(FAVORITES_KEY) || '[]');
  } catch {
    return [];
  }
}

export function saveFavorites(items: SavedNameItem[]) {
  try {
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(items));
  } catch (e) {
    console.error('Failed to save favorites:', e);
  }
}

export function getHistory(): SavedNameItem[] {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
  } catch {
    return [];
  }
}

export function saveHistory(items: SavedNameItem[]) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(items));
  } catch (e) {
    console.error('Failed to save history:', e);
  }
}

export function formatTimestamp(ts: number): string {
  const t = new Date(ts);
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  const h = t.getHours();
  const m = t.getMinutes().toString().padStart(2, '0');
  const ampm = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 || 12;
  return `${t.getDate()} ${months[t.getMonth()]} ${t.getFullYear()}, ${hour12}:${m} ${ampm}`;
}
