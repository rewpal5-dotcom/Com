const uz: Record<string, string> = {
  B: 'ℬ',
  E: 'ℰ',
  F: 'ℱ',
  H: 'ℋ',
  I: 'ℐ',
  L: 'ℒ',
  M: 'ℳ',
  R: 'ℛ',
};

const cz: Record<string, string> = {
  e: 'ℯ',
  g: 'ℊ',
  o: 'ℴ',
};

const fz: Record<string, string> = {
  C: 'ℭ',
  H: 'ℌ',
  I: 'ℑ',
  R: 'ℜ',
  Z: 'ℨ',
};

const dz: Record<string, string> = {
  C: 'ℂ',
  H: 'ℍ',
  N: 'ℕ',
  P: 'ℙ',
  Q: 'ℚ',
  R: 'ℝ',
  Z: 'ℤ',
};

const hz: Record<string, string> = {
  a: 'ᴀ',
  b: 'ʙ',
  c: 'ᴄ',
  d: 'ᴅ',
  e: 'ᴇ',
  f: 'ꜰ',
  g: 'ɢ',
  h: 'ʜ',
  i: 'ɪ',
  j: 'ᴊ',
  k: 'ᴋ',
  l: 'ʟ',
  m: 'ᴍ',
  n: 'ɴ',
  o: 'ᴏ',
  p: 'ᴘ',
  q: 'ǫ',
  r: 'ʀ',
  s: 'ꜱ',
  t: 'ᴛ',
  u: 'ᴜ',
  v: 'ᴠ',
  w: 'ᴡ',
  x: 'x',
  y: 'ʏ',
  z: 'ᴢ',
};

function mapCharRange(
  upperBase: number,
  lowerBase: number,
  upperSpecial: Record<string, string> = {},
  lowerSpecial: Record<string, string> = {}
) {
  return (char: string) => {
    if (upperSpecial[char]) return upperSpecial[char];
    if (lowerSpecial[char]) return lowerSpecial[char];
    const code = char.charCodeAt(0);
    if (code >= 65 && code <= 90) {
      return String.fromCodePoint(upperBase + (code - 65));
    }
    if (code >= 97 && code <= 122) {
      return String.fromCodePoint(lowerBase + (code - 97));
    }
    return char;
  };
}

function mapUpperRange(base: number) {
  return (char: string) => {
    const code = char.toUpperCase().charCodeAt(0);
    if (code >= 65 && code <= 90) {
      return String.fromCodePoint(base + (code - 65));
    }
    return char;
  };
}

export interface FontTransformer {
  id: string;
  name: string;
  fn: (c: string) => string;
}

export const UNICODE_FONTS: FontTransformer[] = [
  { id: 'bold', name: 'Bold', fn: mapCharRange(119808, 119834) },
  { id: 'italic', name: 'Italic', fn: mapCharRange(119860, 119886) },
  { id: 'boldItalic', name: 'Bold Italic', fn: mapCharRange(119912, 119938) },
  { id: 'script', name: 'Script', fn: mapCharRange(119964, 119990, uz, cz) },
  { id: 'boldScript', name: 'Cursive', fn: mapCharRange(120016, 120042) },
  { id: 'fraktur', name: 'Gothic', fn: mapCharRange(120068, 120094, fz) },
  { id: 'doubleStruck', name: 'Boxed', fn: mapCharRange(120120, 120146, dz) },
  { id: 'sansSerif', name: 'Sans', fn: mapCharRange(120224, 120250) },
  { id: 'sansBold', name: 'Sans Bold', fn: mapCharRange(120276, 120302) },
  { id: 'mono', name: 'Mono', fn: mapCharRange(120432, 120458) },
  { id: 'fullwidth', name: 'Fullwidth', fn: mapCharRange(65313, 65345) },
  { id: 'circled', name: 'Bubbles', fn: mapCharRange(9398, 9424) },
  { id: 'squared', name: 'Squared', fn: mapUpperRange(127280) },
  { id: 'negSquared', name: 'Filled Box', fn: mapUpperRange(127344) },
  { id: 'smallCaps', name: 'Small Caps', fn: (e) => hz[e.toLowerCase()] || e },
  { id: 'flag', name: 'Flag Letters', fn: mapUpperRange(127462) },
];

export interface GamerBorder {
  id: string;
  name: string;
  wrap: (text: string) => string;
}

export const GAMER_BORDERS: GamerBorder[] = [
  { id: 'gamer', name: 'Gamer', wrap: (e) => `꧁ड${e}ड꧂` },
  { id: 'ffBrackets', name: 'FF Style', wrap: (e) => `『${e}』` },
  { id: 'star', name: 'Star', wrap: (e) => `★彡${e}彡★` },
  { id: 'arrow', name: 'Arrow', wrap: (e) => `◥꧁${e}꧂◤` },
  { id: 'butterfly', name: 'Butterfly', wrap: (e) => `╰❁${e}❁╯` },
  { id: 'sparkle', name: 'Sparkle', wrap: (e) => `✨${e}✨` },
  { id: 'king', name: 'King', wrap: (e) => `♔ ${e} ♔` },
  { id: 'flame', name: 'Flame', wrap: (e) => `🔥${e}🔥` },
];

export function transformString(text: string, fn: (c: string) => string): string {
  return text.split('').map(fn).join('');
}

export interface GeneratedStyleText {
  label: string;
  text: string;
}

export function generateAllUnicodeStyles(name: string): GeneratedStyleText[] {
  if (!name) return [];
  const results: GeneratedStyleText[] = [];

  // 1. Raw Unicode fonts
  UNICODE_FONTS.forEach((f) => {
    results.push({
      label: f.name,
      text: transformString(name, f.fn),
    });
  });

  // 2. Fancy gamer wrappers with complementary fonts
  const preferredFonts = ['boldScript', 'script', 'boldItalic', 'fraktur', 'fullwidth'];
  GAMER_BORDERS.forEach((b, idx) => {
    const fontId = preferredFonts[idx % preferredFonts.length];
    const foundFont = UNICODE_FONTS.find((f) => f.id === fontId) || UNICODE_FONTS[0];
    const transformed = transformString(name, foundFont.fn);
    results.push({
      label: b.name,
      text: b.wrap(transformed),
    });
  });

  // Deduplicate
  const seen = new Set<string>();
  return results.filter((r) => {
    if (seen.has(r.text)) return false;
    seen.add(r.text);
    return true;
  });
}
