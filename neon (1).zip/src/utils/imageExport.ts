import { StyleDefinition } from '../data/neonStyles';

export function downloadNeonImage(
  name: string,
  style: StyleDefinition,
  options: {
    backgroundColor?: string;
    glowStrength?: number;
    fontSize?: number;
  } = {}
) {
  if (!name) return;

  const {
    backgroundColor = '#0d0d0d',
    glowStrength = 1.2,
    fontSize = 54,
  } = options;

  const canvas = document.createElement('canvas');
  const width = 1200;
  const height = 630;
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Background
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(0, 0, width, height);

  // Subtle background glow radial
  const radial = ctx.createRadialGradient(
    width / 2,
    height / 2,
    50,
    width / 2,
    height / 2,
    width / 2
  );
  radial.addColorStop(0, 'rgba(138, 43, 226, 0.12)');
  radial.addColorStop(1, 'transparent');
  ctx.fillStyle = radial;
  ctx.fillRect(0, 0, width, height);

  // Measure and layout characters
  ctx.font = `800 ${fontSize}px system-ui, -apple-system, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  const chars = name.split('');
  // Measure total width
  let totalWidth = 0;
  const charWidths = chars.map((c) => {
    const w = ctx.measureText(c).width;
    totalWidth += w;
    return w;
  });

  let currentX = width / 2 - totalWidth / 2;
  const centerY = height / 2;

  chars.forEach((char, i) => {
    const color = style.colors[i % style.colors.length];
    const w = charWidths[i];
    const charCenterX = currentX + w / 2;

    ctx.save();

    if (style.effect === 'neon') {
      const h = 12 * glowStrength;
      ctx.shadowColor = color;
      ctx.shadowBlur = h * 2;
      ctx.fillStyle = color;
      ctx.fillText(char, charCenterX, centerY);

      ctx.shadowBlur = h * 3;
      ctx.fillText(char, charCenterX, centerY);
    } else if (style.effect === 'glow') {
      const h = 8 * glowStrength;
      ctx.shadowColor = color;
      ctx.shadowBlur = h;
      ctx.fillStyle = color;
      ctx.fillText(char, charCenterX, centerY);
    } else if (style.effect === '3d') {
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      for (let s = 6; s >= 1; s--) {
        ctx.fillText(char, charCenterX + s, centerY + s);
      }
      ctx.fillStyle = color;
      ctx.fillText(char, charCenterX, centerY);
    } else if (style.effect === 'fire') {
      ctx.shadowColor = '#FF0000';
      ctx.shadowBlur = 18;
      ctx.fillStyle = color;
      ctx.fillText(char, charCenterX, centerY);
    } else if (style.effect === 'ice') {
      ctx.shadowColor = '#00BFFF';
      ctx.shadowBlur = 20;
      ctx.fillStyle = color;
      ctx.fillText(char, charCenterX, centerY);
    } else {
      ctx.fillStyle = color;
      ctx.fillText(char, charCenterX, centerY);
    }

    ctx.restore();
    currentX += w;
  });

  // Watermark
  ctx.font = '500 14px system-ui, sans-serif';
  ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
  ctx.fillText('NeonName · Name Color Generator', width / 2, height - 35);

  const url = canvas.toDataURL('image/png');
  const a = document.createElement('a');
  a.href = url;
  a.download = `${name.replace(/[^a-zA-Z0-9]/g, '_')}_neon_name.png`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}
