import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize GoogleGenAI server-side with telemetry header
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Enhance video prompt using Gemini 3.8 Flash
app.post('/api/enhance-prompt', async (req, res) => {
  try {
    const { prompt, videoType = 'realistic', style = 'cinematic', duration = 4 } = req.body;

    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    if (ai) {
      try {
        const timeoutPromise = new Promise<null>((_, reject) =>
          setTimeout(() => reject(new Error('Gemini timeout')), 4500)
        );
        const genPromise = ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `You are an expert AI video prompt engineer for state-of-the-art video diffusion models like Sora 2.
Enhance the following user prompt for video generation.
The user might write in Hindi, English, or Hinglish (e.g. "Billi ek badi si chuha ke piche...").
Preserve the core concept, humor, and story. Enrich it with:
1. Specific camera movement (e.g. tracking pan, slow-motion drone flyby, low-angle shot)
2. Atmospheric lighting, environment details, textures, and depth of field
3. Specific character or subject actions and natural physics
4. Style: ${videoType} (${style})
Target duration: ${duration}s.

Output ONLY a concise, vivid prompt (under 80 words) ready to feed directly into Sora 2. Do not include markdown prefixes or quotes.

User prompt: "${prompt}"`,
        });

        const response: any = await Promise.race([genPromise, timeoutPromise]);
        const enhanced = response?.text?.trim() || prompt;
        return res.json({ enhancedPrompt: enhanced });
      } catch (geminiErr) {
        console.warn('Gemini enhancement error or timeout, using fallback:', geminiErr);
      }
    }

    // Heuristic fallback enhancement if no API key or error
    const cameraMoves = [
      'cinematic dynamic tracking shot, 8k resolution, volumetric lighting, photorealistic depth of field',
      'low-angle dolly zoom, rich textures, hyper-detailed motion blur, realistic physics simulation',
      'smooth drone aerial sweep, golden hour illumination, ultra-high definition clarity',
    ];
    const pickedMove = cameraMoves[Math.floor(Math.random() * cameraMoves.length)];
    const fallbackEnhanced = `${prompt}, ${pickedMove}, ${videoType} style, vibrant atmosphere, highly detailed`;

    return res.json({ enhancedPrompt: fallbackEnhanced });
  } catch (error) {
    console.error('Enhance prompt endpoint error:', error);
    return res.status(500).json({ error: 'Failed to enhance prompt' });
  }
});

// Scene Storyboard / Generation helper
app.post('/api/generate-scene', async (req, res) => {
  try {
    const { prompt, videoType = 'realistic' } = req.body;
    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `Create a brief 3-beat visual scene progression for a video prompt: "${prompt}".
Style: ${videoType}.
Return JSON format with:
{
  "beats": ["Beat 1 description", "Beat 2 description", "Beat 3 description"],
  "palette": ["primary color hex", "secondary color hex", "accent color hex"],
  "mood": "Brief mood"
}`,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const text = response.text?.trim();
        if (text) {
          const parsed = JSON.parse(text);
          return res.json(parsed);
        }
      } catch (err) {
        console.warn('Gemini storyboard error, fallback:', err);
      }
    }

    return res.json({
      beats: [
        'Opening establishing shot with dynamic lighting',
        'Main action unfolding with fluid camera movement',
        'Dramatic culmination with cinematic focus',
      ],
      palette: ['#9333ea', '#3b82f6', '#ec4899'],
      mood: 'Dynamic and immersive',
    });
  } catch (error) {
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Start server with Vite middleware in dev or static files in prod
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Video Generator server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
